--
-- PostgreSQL database dump
--

\restrict DVk09rTV82noT4HSIgxYbvLdegKEDfdNza1DhbfhAM2sILYJkRvxK5loPkBmxcZ

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: dumtools
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'MEMBRE'
);


ALTER TYPE public."Role" OWNER TO dumtools;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AffectationProjet; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."AffectationProjet" (
    id text NOT NULL,
    nom text DEFAULT 'Nouveau projet'::text NOT NULL,
    "clientNom" text DEFAULT ''::text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "clientId" text,
    "numeroWhy" text
);


ALTER TABLE public."AffectationProjet" OWNER TO dumtools;

--
-- Name: AutomateModele; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."AutomateModele" (
    id text NOT NULL,
    reference text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    image text DEFAULT ''::text NOT NULL,
    "alimIntegree" boolean DEFAULT false NOT NULL,
    "alimLabel" text DEFAULT ''::text NOT NULL,
    "entreeKind" text DEFAULT 'UI'::text NOT NULL,
    "entreeCount" integer DEFAULT 0 NOT NULL,
    "sortieKind" text DEFAULT 'UO'::text NOT NULL,
    "sortieCount" integer DEFAULT 0 NOT NULL,
    "entreeCodes" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "sortieCodes" jsonb DEFAULT '[]'::jsonb NOT NULL,
    extensible boolean DEFAULT false NOT NULL,
    "modulesCompat" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AutomateModele" OWNER TO dumtools;

--
-- Name: Chantier; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."Chantier" (
    id text NOT NULL,
    nom text NOT NULL,
    reference text,
    "clientId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Chantier" OWNER TO dumtools;

--
-- Name: Client; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."Client" (
    id text NOT NULL,
    nom text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Client" OWNER TO dumtools;

--
-- Name: Modele; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."Modele" (
    id text NOT NULL,
    nom text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    points jsonb DEFAULT '[]'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Modele" OWNER TO dumtools;

--
-- Name: ModuleModele; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."ModuleModele" (
    id text NOT NULL,
    type text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    image text DEFAULT ''::text NOT NULL,
    categorie text DEFAULT 'extension'::text NOT NULL,
    "entreeKind" text DEFAULT 'UI'::text NOT NULL,
    "entreeCount" integer DEFAULT 0 NOT NULL,
    "sortieKind" text DEFAULT 'UO'::text NOT NULL,
    "sortieCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ModuleModele" OWNER TO dumtools;

--
-- Name: PointCatalog; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."PointCatalog" (
    id text NOT NULL,
    nom text NOT NULL,
    type text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PointCatalog" OWNER TO dumtools;

--
-- Name: PointsList; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."PointsList" (
    id text NOT NULL,
    titre text,
    "clientNom" text DEFAULT ''::text NOT NULL,
    "chantierNom" text DEFAULT ''::text NOT NULL,
    date timestamp(3) without time zone,
    rows jsonb DEFAULT '[]'::jsonb NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "clientId" text,
    "numeroWhy" text
);


ALTER TABLE public."PointsList" OWNER TO dumtools;

--
-- Name: User; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    nom text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."Role" DEFAULT 'MEMBRE'::public."Role" NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO dumtools;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: dumtools
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO dumtools;

--
-- Data for Name: AffectationProjet; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."AffectationProjet" (id, nom, "clientNom", data, "createdById", "createdAt", "updatedAt", "clientId", "numeroWhy") FROM stdin;
cmr9deer20000lj1xxa013gz6	Depuis liste de points		{"date": "juillet 2026", "name": "Depuis liste de points", "header": "CLIENT - SITE", "points": [], "modules": [], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "Affectation des entrées / sorties", "power_supply": "none", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-06 15:23:56.078	2026-07-06 15:23:57.278	\N	\N
cmr9df00y0001lj1xgozsrlox	DALKIA FRANCE	DALKIA FRANCE	{"date": "juillet 2026", "name": "DALKIA FRANCE", "header": "DALKIA FRANCE - Chaufferie Test", "points": [{"uid": "c7e9e67992d84cf0a9ff4efdc2ac2954", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde extérieur"}, {"uid": "124e62c88a044b35a6fa3218dabc7436", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "P1", "channel": null, "direction": "output", "designation": "Commande pompe 1"}], "modules": [], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "Affectation des entrées / sorties", "power_supply": "none", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-06 15:24:23.65	2026-07-06 18:40:30.476	cmr98uwge001c821x4sas8mk5	\N
cmr9dlmcw0002lj1xu0k0sqlg	DALKIA FRANCE	DALKIA FRANCE	{"date": "juillet 2026", "name": "DALKIA FRANCE", "header": "DALKIA FRANCE - Chaufferie Test", "points": [{"uid": "bba7d58bad5845d1b0c51c82e2ff40ff", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde extérieur"}, {"uid": "9e04c25479224301af005d1a9deed2ea", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "P1", "channel": null, "direction": "output", "designation": "Commande pompe 1"}], "modules": [], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "Affectation des entrées / sorties", "power_supply": "none", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-06 15:29:32.528	2026-07-06 18:40:30.473	cmr98uwge001c821x4sas8mk5	\N
cmraa5cdg0003n71x3dzvulnu	COPRECS	COPRECS	{"date": "juillet 2026", "name": "COPRECS", "header": "COPRECS - Piscine — Château-Thierry", "points": [{"uid": "fa919c06ff314948829d07655214148c", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde extérieur"}, {"uid": "0f02b8fa1d4e45678edd782976e5573c", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde départ primaire"}, {"uid": "b657ee5c7bdd4333bfcfea54f77dab95", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut Manque Eau"}, {"uid": "3811c32f47454ac6822b11f59108637f", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut Manque Gaz"}, {"uid": "760245354ed54d33963936f5283ff51a", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut Manque Tension"}, {"uid": "1510330fe1e14b38981ec3cb39475f3d", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe de relevage"}, {"uid": "393db470b6544aaaa10d69635207337f", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde départ"}, {"uid": "08e870ceefce451090bebc6d8dbdd454", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde ambiance"}, {"uid": "1353c40d95f4454fb6f4ba138cb1f4eb", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande Vanne 3 voies"}, {"uid": "b66ba9b712ab48619beaa34f948221dd", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande pompe 1"}, {"uid": "82f5d0344d8f4f1b93c398dd9b0cc371", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande pompe 2"}, {"uid": "4456b6522c014de3a6c6b5241dc1d052", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe 1"}, {"uid": "11fb34be504c4bd9b1afd9ddd1e60398", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe 2"}], "modules": [], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "Affectation des entrées / sorties", "power_supply": "none", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-07 06:40:40.42	2026-07-07 07:05:30.697	cmr98uwge0016821xipr1x4he	\N
cmr9ka8ag0005lj1xdo38kgzi	ADICA	ADICA	{"date": "juillet 2026", "name": "ADICA", "header": "ADICA - TEST GUS", "points": [{"uid": "d64696bdd62b4fd7831f43497d96bcf2", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde départ"}, {"uid": "ada47318853c48ff8b1def4003dbbcb9", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde ambiance"}, {"uid": "88776e52c2cb4fae93317c29a2fa89ec", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande Vanne 3 voies"}, {"uid": "1075468396f44967b65ea5d9c839e944", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande pompe 1"}, {"uid": "994e108eaa1b46df844ea103c6cd40aa", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande pompe 2"}, {"uid": "c361b50d00214339ae2fb0702f424fd5", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe 1"}, {"uid": "38f901fda54444c8920e624349b297be", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe 2"}, {"uid": "5e2a358231b844f7b1fb41253942bce4", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde départ chaudiere 1"}, {"uid": "3c3797046a9445c9a1df5b0d52fd7bfc", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde départ chaudiere 2"}, {"uid": "0fd4db1004f24687b56c3e7665dd5267", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande chaudiére 1"}, {"uid": "ef998dfe003e4c6fa0824106ace64106", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande chaudiére 2"}, {"uid": "4684201dbd5547378b7cec6559e3fa5d", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut chaudière 1"}, {"uid": "848214a8465d429dbb477290782a23ff", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut chaudière 2"}, {"uid": "18a0a2df6b3c417eb54fb4a3f7d988f5", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande Vanne 2 voies"}, {"uid": "04be34ddaec84f4d82ef9be6d5a74d6c", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande Vanne 2 voies"}, {"uid": "b23d2b11b6e14e67aefbf5e912b01963", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Capteur pression"}], "modules": [], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "Affectation des entrées / sorties", "power_supply": "none", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-06 18:36:38.393	2026-07-07 06:14:51.428	cmr98uwgc0003821xju11f4vl	\N
cmr9c3do20000m31xmnyu7kkr	ECYS1000E_DUMORTIER_1CH_1CR	DALKIA FRANCE	{"date": "juin 2026", "name": "ECYS1000E_DUMORTIER_1CH_1CR", "header": "ECYS1000E DUMORTIER 1CH 1CR", "points": [{"uid": "554b05b4af2b4db38f5bcf5919d6c92b", "relay": "", "active": true, "module": 1, "repere": "UI1", "signal": "T", "source": "Import GFX - Module 1 / UI1", "channel": 1, "direction": "input", "designation": "Tp Exterieure"}, {"uid": "7eb3d35aaa9d43a98f7a3c817d9fbc64", "relay": "", "active": true, "module": 1, "repere": "UI2", "signal": "T", "source": "Import GFX - Module 1 / UI2", "channel": 2, "direction": "input", "designation": "CHD - Tp Depart"}, {"uid": "2f420166cd054687961518c40f15f5e7", "relay": "", "active": true, "module": 1, "repere": "UI3", "signal": "T", "source": "Import GFX - Module 1 / UI3", "channel": 3, "direction": "input", "designation": "CR - Tp Depart"}, {"uid": "c46c4bf181bb460380f1a1d9bcf03888", "relay": "", "active": true, "module": 1, "repere": "UI4", "signal": "D", "source": "Import GFX - Module 1 / UI4", "channel": 4, "direction": "input", "designation": "CR - Defaut Ppe 1"}, {"uid": "a503943ec86d41a0bf3fb8fbf1806fc3", "relay": "", "active": true, "module": 1, "repere": "UI5", "signal": "D", "source": "Import GFX - Module 1 / UI5", "channel": 5, "direction": "input", "designation": "CR - Defaut Ppe 2"}, {"uid": "017749dc8d3140fd950ad07bf8dcdff7", "relay": "", "active": true, "module": 1, "repere": "UI6", "signal": "D", "source": "Import GFX - Module 1 / UI6", "channel": 6, "direction": "input", "designation": "Manque Eau"}, {"uid": "380d86ed2a1547d1b905a2f8728944d5", "relay": "", "active": true, "module": 1, "repere": "UI7", "signal": "D", "source": "Import GFX - Module 1 / UI7", "channel": 7, "direction": "input", "designation": "CHD - Defaut"}, {"uid": "fb44f91e7dcc4bfba4fd0e8110377fba", "relay": "", "active": true, "module": 1, "repere": "UO1", "signal": "0-10V", "source": "Import GFX - Module 1 / UO1", "channel": 1, "direction": "output", "designation": "CR - Signal 0-10V V3V (avec ou sans 2RM)"}, {"uid": "01674287015f4b3bba7a79d9e998e4e9", "relay": "", "active": true, "module": 1, "repere": "UO2", "signal": "0-10V", "source": "Import GFX - Module 1 / UO2", "channel": 2, "direction": "output", "designation": "CHD - Signal 0-10V"}, {"uid": "39c91806ef644a11aceb6d139fe6a974", "relay": "RE-12DC", "active": true, "module": 1, "repere": "UO3", "signal": "D", "source": "Import GFX - Module 1 / UO3", "channel": 3, "direction": "output", "designation": "CR - ODM Ppe 1"}, {"uid": "98c4c3e298334ca2adf228e43d5bc788", "relay": "RE-12DC", "active": true, "module": 1, "repere": "UO4", "signal": "D", "source": "Import GFX - Module 1 / UO4", "channel": 4, "direction": "output", "designation": "CR - ODM Ppe 2"}], "modules": [{"type": "8UI6UO", "number": 1, "moduleId": "1", "gfxNumber": 1, "inputKind": "UI", "inputCount": 8, "outputKind": "UO", "outputCount": 6}], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-ABCD", "controller": "ECY-S1000E-48", "gfx_header_2": "", "gfx_header_3": "ECY-S1000E-48 - Affectation des entrées / sorties", "power_supply": "none", "controller_ip": "192.168.1.50", "wifi_password": "1234", "document_title": "Affectation entrées sorties automate Distech Controls\\n« ECYS1000E DUMORTIER 1CH 1CR »", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-06 14:47:21.842	2026-07-07 06:15:01.726	cmr98uwge001c821x4sas8mk5	\N
cmrad6f9n0000hh1x29x8vivr	COPRECS	COPRECS	{"date": "juillet 2026", "name": "COPRECS", "header": "COPRECS - Piscine — Château-Thierry", "points": [{"uid": "750168485fbd4781906020a1484a7dfc", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde extérieur"}, {"uid": "7163b7075ed44d04b6cdfe6ba166e49e", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde départ primaire"}, {"uid": "e2f5b1a5699d4d4994767bde532a58af", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut Manque Eau"}, {"uid": "e513324cfb4c4ae48b5592c7e9008fe0", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut Manque Gaz"}, {"uid": "92802c700b0944bcbda9c2d604afd0bf", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut Manque Tension"}, {"uid": "0318917015ab478cbc83969c43764852", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe de relevage"}, {"uid": "0d6c4295d75247f78abb5e1fc62e7244", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde départ"}, {"uid": "9a82cbd65f08441a8358a3d83cbda8ce", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Sonde ambiance"}, {"uid": "6ced6d921fe0436a8c6c4d3f4db8bc7b", "relay": "", "active": true, "module": null, "repere": "", "signal": "0-10V", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande Vanne 3 voies"}, {"uid": "61b91bd2ea7b4da19ad24d229cf0dee5", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande pompe 1"}, {"uid": "53955d7e50d14b389e6348c61e198494", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "output", "designation": "Commande pompe 2"}, {"uid": "86801d0e8d78499cb915ba726e0a9fb6", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe 1"}, {"uid": "8470f0bf6b3c4f54a5335ed269711ae8", "relay": "", "active": true, "module": null, "repere": "", "signal": "D", "source": "Depuis liste de points", "channel": null, "direction": "input", "designation": "Defaut pompe 2"}], "modules": [{"type": "8UI6UO", "number": 1, "inputKind": "UI", "inputCount": 8, "outputKind": "UO", "outputCount": 6}], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "ECY-300", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "Affectation des entrées / sorties", "power_supply": "integrated", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-07 08:05:29.675	2026-07-07 09:32:00.294	cmr98uwge0016821xipr1x4he	\N
cmra9axoz0001n71xyj09ttsm	STO_CERVILLE_MES_30-06-2026-1CHD-1CR-1CST		{"date": "juin 2026", "name": "STO_CERVILLE_MES_30-06-2026-1CHD-1CR-1CST", "header": "STO CERVILLE MES 30-06-2026-1CHD-1CR-1CST", "points": [{"uid": "d46c0bc353a94fe689eb12bf36f8d4ee", "relay": "", "active": true, "module": 1, "repere": "UI1", "signal": "T", "source": "Import GFX - Module 1 / UI1", "channel": 1, "direction": "input", "testStatus": "ok", "designation": "Temp_Exterieur"}, {"uid": "05f6011f7f2c44a7b068069936229ba8", "relay": "", "active": true, "module": 1, "repere": "UI2", "signal": "T", "source": "Import GFX - Module 1 / UI2", "channel": 2, "direction": "input", "designation": "CHD_Temperature_Depart"}, {"uid": "7f900a394b45432291218ebeed43c867", "relay": "", "active": true, "module": 1, "repere": "UI3", "signal": "T", "source": "Import GFX - Module 1 / UI3", "channel": 3, "direction": "input", "designation": "CR1_Temperature_Depart"}, {"uid": "958af5c3fb6b431491246c421221f0c9", "relay": "", "active": true, "module": 1, "repere": "UI5", "signal": "T", "source": "Import GFX - Module 1 / UI5", "channel": 5, "direction": "input", "designation": "CST_Temperature_Depart"}, {"uid": "563f93143a4644e0bd96fa9050d3e402", "relay": "", "active": true, "module": 1, "repere": "UI7", "signal": "D", "source": "Import GFX - Module 1 / UI7", "channel": 7, "direction": "input", "designation": "CR1_Defaut_Pompe_1"}, {"uid": "d76d7b6df64f49faabdeec2b55863387", "relay": "", "active": true, "module": 1, "repere": "UI8", "signal": "D", "source": "Import GFX - Module 1 / UI8", "channel": 8, "direction": "input", "designation": "CR1_Defaut_Pompe_2"}, {"uid": "2387e2069a2440bba97cefa5434c7770", "relay": "", "active": true, "module": 2, "repere": "UI1", "signal": "D", "source": "Import GFX - Module 2 / UI1", "channel": 1, "direction": "input", "designation": "CST_Defaut_Pompe_1"}, {"uid": "a6e5fbeffdf841e0b44af14bcb79db59", "relay": "", "active": true, "module": 2, "repere": "UI2", "signal": "D", "source": "Import GFX - Module 2 / UI2", "channel": 2, "direction": "input", "designation": "CST_Defaut_Pompe_2"}, {"uid": "22a03ddce08744afbe6d6eb1616b4ed1", "relay": "", "active": true, "module": 2, "repere": "UI4", "signal": "D", "source": "Import GFX - Module 2 / UI4", "channel": 4, "direction": "input", "designation": "CHD_Defaut_Chaudiere"}, {"uid": "abbbf2b55c8b4e3488d45003893cc370", "relay": "", "active": true, "module": 2, "repere": "UI5", "signal": "D", "source": "Import GFX - Module 2 / UI5", "channel": 5, "direction": "input", "designation": "Manque_Eau"}, {"uid": "d5f8d151ce7648c5847f8e8e71fff5b2", "relay": "", "active": true, "module": 1, "repere": "UO1", "signal": "0-10V", "source": "Import GFX - Module 1 / UO1", "channel": 1, "direction": "output", "designation": "CHD_Pilotage-0-10V"}, {"uid": "8edc498b4e984d05891f98f52d9fe847", "relay": "RE-12DC", "active": true, "module": 1, "repere": "UO2", "signal": "D", "source": "Import GFX - Module 1 / UO2", "channel": 2, "direction": "output", "designation": "CHD_Autorisation"}, {"uid": "2b9cae0ae5414cc082f97e03dec0b4c5", "relay": "", "active": true, "module": 1, "repere": "UO3", "signal": "0-10V", "source": "Import GFX - Module 1 / UO3", "channel": 3, "direction": "output", "designation": "CR1_Pilotage-0-10V"}, {"uid": "a92969d95a50459eb07fe2f03574bc28", "relay": "RE-12DC", "active": true, "module": 1, "repere": "UO5", "signal": "D", "source": "Import GFX - Module 1 / UO5", "channel": 5, "direction": "output", "designation": "CST_ODM_Pompe_1"}, {"uid": "ba9170bf85fd40e6a8772588cc2ed7ed", "relay": "RE-12DC", "active": true, "module": 1, "repere": "UO6", "signal": "D", "source": "Import GFX - Module 1 / UO6", "channel": 6, "direction": "output", "designation": "CST_ODM_Pompe_2"}, {"uid": "998a1cf8a53a4f278eb84c899a203495", "relay": "RE-12DC", "active": true, "module": 2, "repere": "UO3", "signal": "D", "source": "Import GFX - Module 2 / UO3", "channel": 3, "direction": "output", "designation": "CR1_ODM_Pompe_1"}, {"uid": "455c8cfea58b42c884912e32f004c866", "relay": "RE-12DC", "active": true, "module": 2, "repere": "UO4", "signal": "D", "source": "Import GFX - Module 2 / UO4", "channel": 4, "direction": "output", "designation": "CR1_ODM_Pompe_2"}], "modules": [{"type": "8UI6UO", "number": 1, "moduleId": "1", "gfxNumber": 1, "inputKind": "UI", "inputCount": 8, "outputKind": "UO", "outputCount": 6}, {"type": "8UI6UO", "number": 2, "moduleId": "1", "gfxNumber": 2, "inputKind": "UI", "inputCount": 8, "outputKind": "UO", "outputCount": 6}], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "ECY-S1000E-48", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "ECY-S1000E-48 - Affectation des entrées / sorties", "power_supply": "integrated", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls\\n« STO CERVILLE MES 30-06-2026-1CHD-1CR-1CST »", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmr97nnti0000151x5566cx94	2026-07-07 06:17:01.715	2026-07-07 17:29:59.405	\N	\N
cmradidbw0001hh1xk3zoq5tw	S1000_DW261115 COLAS WIGNERIE		{"date": "juillet 2026", "name": "S1000_DW261115 COLAS WIGNERIE", "header": "S1000 DW261115 COLAS WIGNERIE", "points": [{"uid": "mradiwr2ez3zfuvvq8l", "relay": "", "active": true, "module": 1, "repere": "UI1", "signal": "T", "source": "Import PDF - Module 1 / UI1 (p.5)", "channel": 1, "direction": "input", "testStatus": "non-teste", "designation": "SDE AMB Z1 CLASSE 00", "testComment": ""}, {"uid": "mradiwr2yclu5g0fa4b", "relay": "", "active": true, "module": 1, "repere": "UI2", "signal": "T", "source": "Import PDF - Module 1 / UI2 (p.5)", "channel": 2, "direction": "input", "designation": "SDE AMB Z2 CLASSE 01"}, {"uid": "mradiwr28qyjfs4amd5", "relay": "", "active": true, "module": 1, "repere": "UI3", "signal": "T", "source": "Import PDF - Module 1 / UI3 (p.5)", "channel": 3, "direction": "input", "designation": "SDE AMB Z3 CLASSE 02"}, {"uid": "mradiwr27gc8uykwz0g", "relay": "", "active": true, "module": 1, "repere": "UI4", "signal": "T", "source": "Import PDF - Module 1 / UI4 (p.5)", "channel": 4, "direction": "input", "designation": "SDE AMB Z4 DIRECTION"}, {"uid": "mradiwr2a8fz08s5j8h", "relay": "", "active": true, "module": 1, "repere": "UI5", "signal": "T", "source": "Import PDF - Module 1 / UI5 (p.5)", "channel": 5, "direction": "input", "designation": "SDE AMB Z5 BUREAU"}, {"uid": "mradiwr2i638ld121uj", "relay": "", "active": true, "module": 1, "repere": "UI6", "signal": "T", "source": "Import PDF - Module 1 / UI6 (p.5)", "channel": 6, "direction": "input", "designation": "SDE AMB Z6 CLASSE 03"}, {"uid": "mradiwr2dmowttj94xi", "relay": "", "active": true, "module": 1, "repere": "UI7", "signal": "T", "source": "Import PDF - Module 1 / UI7 (p.5)", "channel": 7, "direction": "input", "designation": "SDE AMB Z7 DEGAGEMENT 00"}, {"uid": "mradiwr2bwgogg8lwir", "relay": "", "active": true, "module": 1, "repere": "UI8", "signal": "T", "source": "Import PDF - Module 1 / UI8 (p.5)", "channel": 8, "direction": "input", "designation": "SDE AMB Z8 TISANNERIE"}, {"uid": "mradiwr2q0vwewriz8d", "relay": "", "active": true, "module": 1, "repere": "UO1", "signal": "0-10V", "source": "Import PDF - Module 1 / UO1 (p.5)", "channel": 1, "direction": "output", "designation": "V2V ZONE N°1 V2V ZONE N°2 CLASSE 00 CLASSE 01"}, {"uid": "mradiwr296el4napx2m", "relay": "", "active": true, "module": 1, "repere": "UO2", "signal": "0-10V", "source": "Import PDF - Module 1 / UO2 (p.5)", "channel": 2, "direction": "output", "designation": "V2V ZONE N°2 CLASSE 01"}, {"uid": "mradiwr2el3vhn5a0cu", "relay": "", "active": true, "module": 1, "repere": "UO3", "signal": "0-10V", "source": "Import PDF - Module 1 / UO3 (p.5)", "channel": 3, "direction": "output", "designation": "V2V ZONE N°3 CLASSE 02"}, {"uid": "mradiwr2n0c5b1ugou", "relay": "", "active": true, "module": 1, "repere": "UO4", "signal": "0-10V", "source": "Import PDF - Module 1 / UO4 (p.5)", "channel": 4, "direction": "output", "designation": "V2V ZONE N°4 DIRECTION"}, {"uid": "mradiwr2qjka2mu8xqp", "relay": "", "active": true, "module": 1, "repere": "UO5", "signal": "0-10V", "source": "Import PDF - Module 1 / UO5 (p.5)", "channel": 5, "direction": "output", "designation": "V2V ZONE N°5 BUREAU"}, {"uid": "mradiwr2aegb038xdw8", "relay": "", "active": true, "module": 1, "repere": "UO6", "signal": "0-10V", "source": "Import PDF - Module 1 / UO6 (p.5)", "channel": 6, "direction": "output", "designation": "V2V ZONE N°5 V2V ZONE N°6 BUREAU CLASSE 03"}, {"uid": "mradiwr2g6jlii5frnr", "relay": "", "active": true, "module": 2, "repere": "UI1", "signal": "T", "source": "Import PDF - Module 2 / UI1 (p.6)", "channel": 1, "direction": "input", "designation": "SDE AMB Z9 DORTOIR 01"}, {"uid": "mradiwr2ce80f5pa90a", "relay": "", "active": true, "module": 2, "repere": "UI2", "signal": "T", "source": "Import PDF - Module 2 / UI2 (p.6)", "channel": 2, "direction": "input", "designation": "SDE AMB Z10 ACCUEIL"}, {"uid": "mradiwr2qqolk8h29yr", "relay": "", "active": true, "module": 2, "repere": "UI3", "signal": "T", "source": "Import PDF - Module 2 / UI3 (p.6)", "channel": 3, "direction": "input", "designation": "SDE AMB Z11 CLASSE 05"}, {"uid": "mradiwr24odvhk6i9dk", "relay": "", "active": true, "module": 2, "repere": "UI4", "signal": "T", "source": "Import PDF - Module 2 / UI4 (p.6)", "channel": 4, "direction": "input", "designation": "SDE AMB Z12 DORTOIR 00"}, {"uid": "mradiwr2r6pc2m9jk1o", "relay": "", "active": true, "module": 2, "repere": "UI5", "signal": "T", "source": "Import PDF - Module 2 / UI5 (p.6)", "channel": 5, "direction": "input", "designation": "SDE AMB Z13 CLASSE 04"}, {"uid": "mradiwr24yy5vl4v658", "relay": "", "active": true, "module": 2, "repere": "UI6", "signal": "T", "source": "Import PDF - Module 2 / UI6 (p.6)", "channel": 6, "direction": "input", "designation": "SDE AMB Z14 WC 01"}, {"uid": "mradiwr2n0f3vn6kat", "relay": "", "active": true, "module": 2, "repere": "UI7", "signal": "T", "source": "Import PDF - Module 2 / UI7 (p.6)", "channel": 7, "direction": "input", "designation": "SDE AMB Z15 WC 00"}, {"uid": "mradiwr2h2b4y8tt2ww", "relay": "", "active": true, "module": 2, "repere": "UO1", "signal": "0-10V", "source": "Import PDF - Module 2 / UO1 (p.6)", "channel": 1, "direction": "output", "designation": "V2V ZONE N°7 V2V ZONE N°8 DEGAGEMENT 00 TISANERIE"}, {"uid": "mradiwr2oxoarzzv7n", "relay": "", "active": true, "module": 2, "repere": "UO2", "signal": "0-10V", "source": "Import PDF - Module 2 / UO2 (p.6)", "channel": 2, "direction": "output", "designation": "V2V ZONE N°8 TISANERIE"}, {"uid": "mradiwr26gcn90xwfbo", "relay": "", "active": true, "module": 2, "repere": "UO3", "signal": "0-10V", "source": "Import PDF - Module 2 / UO3 (p.6)", "channel": 3, "direction": "output", "designation": "V2V ZONE N°9 DORTOIR 01"}, {"uid": "mradiwr2skhaf4mswv", "relay": "", "active": true, "module": 2, "repere": "UO4", "signal": "0-10V", "source": "Import PDF - Module 2 / UO4 (p.6)", "channel": 4, "direction": "output", "designation": "V2V ZONE N°10 ACCUEIL"}, {"uid": "mradiwr2qwe1kt2cmy", "relay": "", "active": true, "module": 2, "repere": "UO5", "signal": "0-10V", "source": "Import PDF - Module 2 / UO5 (p.6)", "channel": 5, "direction": "output", "designation": "V2V ZONE N°11 CLASSE 05"}, {"uid": "mradiwr2zzp75irnoce", "relay": "", "active": true, "module": 2, "repere": "UO6", "signal": "0-10V", "source": "Import PDF - Module 2 / UO6 (p.6)", "channel": 6, "direction": "output", "designation": "V2V ZONE N°11 V2V ZONE N°1 CLASSE 05 DORTOIR 00"}, {"uid": "mradiwr2nor7ezh6p7", "relay": "", "active": true, "module": 3, "repere": "UI1", "signal": "D", "source": "Import PDF - Module 3 / UI1 (p.7)", "channel": 1, "direction": "input", "designation": "PRESSOSTAT AIR N°1"}, {"uid": "mradiwr2r615c2favc", "relay": "", "active": true, "module": 3, "repere": "UI2", "signal": "D", "source": "Import PDF - Module 3 / UI2 (p.7)", "channel": 2, "direction": "input", "designation": "PRESSOSTAT AIR N°2"}, {"uid": "mradiwr2iqmuy5z3qv", "relay": "", "active": true, "module": 3, "repere": "UI3", "signal": "D", "source": "Import PDF - Module 3 / UI3 (p.7)", "channel": 3, "direction": "input", "designation": "DEFAUT ALARME"}, {"uid": "mradiwr2rw06kpc5y7", "relay": "", "active": true, "module": 3, "repere": "UO1", "signal": "0-10V", "source": "Import PDF - Module 3 / UO1 (p.7)", "channel": 1, "direction": "output", "designation": "V2V ZONE N°13 CLASSE 04"}, {"uid": "mradiwr23ymlwildmab", "relay": "", "active": true, "module": 3, "repere": "UO2", "signal": "0-10V", "source": "Import PDF - Module 3 / UO2 (p.7)", "channel": 2, "direction": "output", "designation": "V2V ZONE N°14 WC 01"}, {"uid": "mradiwr2ybckve1uuy", "relay": "", "active": true, "module": 3, "repere": "UO3", "signal": "0-10V", "source": "Import PDF - Module 3 / UO3 (p.7)", "channel": 3, "direction": "output", "designation": "V2V ZONE N°15 WC 02"}], "modules": [{"type": "RS485", "number": -1, "moduleId": "", "inputKind": "", "inputCount": 0, "outputKind": "", "outputCount": 0}, {"type": "8UI6UO", "number": 1, "moduleId": "", "inputKind": "UI", "inputCount": 8, "outputKind": "UO", "outputCount": 6}, {"type": "8UI6UO", "number": 2, "moduleId": "", "inputKind": "UI", "inputCount": 8, "outputKind": "UO", "outputCount": 6}, {"type": "4UI4UO", "number": 3, "moduleId": "", "inputKind": "UI", "inputCount": 4, "outputKind": "UO", "outputCount": 4}], "version": "1.0", "network_1": "RJ45 - BACnet/IP", "network_2": "RJ45 - supervision", "wifi_ssid": "ECLYPSE-XXXX", "controller": "ECY-S1000E-48", "gfx_header_2": "CLIENT - SITE", "gfx_header_3": "ECY-S1000E-48 - Affectation des entrées / sorties", "power_supply": "230V", "controller_ip": "?.?.?.?", "wifi_password": "????", "document_title": "Affectation entrées sorties automate Distech Controls\\n« S1000 DW261115 COLAS WIGNERIE »", "include_references": false, "gfx_include_generalities": true, "gfx_include_standard_blocks": false}	cmradfrl50000fq1x5gzxk8m4	2026-07-07 08:14:47.036	2026-07-07 08:17:51.981	\N	\N
\.


--
-- Data for Name: AutomateModele; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."AutomateModele" (id, reference, ordre, actif, image, "alimIntegree", "alimLabel", "entreeKind", "entreeCount", "sortieKind", "sortieCount", "entreeCodes", "sortieCodes", extensible, "modulesCompat", "createdAt", "updatedAt") FROM stdin;
cmrabpkr60073nc1xu90zqnjv	ECY-450	1	t	/materiel/ctrl-ECY-400.png	t	24 VAC/DC intégrée	UI	12	UO	12	[]	[]	f	[]	2026-07-07 07:24:24.018	2026-07-07 07:24:24.018
cmrabpkr70076nc1xjly5nxme	ECY-PTU-207	4	t	/materiel/ctrl-ECY-PTU-207.png	t	100–240 VAC intégrée	UI	6	OUT	10	["UI1", "UI2", "UI3", "SI4", "DI5", "DI6"]	["DO1", "DO2", "DO3", "DO4", "DO5", "DO6", "AO7", "AO8", "AO9", "AO10"]	f	[]	2026-07-07 07:24:24.018	2026-07-07 07:24:24.018
cmrabpkr70077nc1xquf1pbeu	ECY-300	5	t	/materiel/ctrl-ECY-300.png	t	24 VAC/DC intégrée	UI	10	UO	8	[]	[]	f	[]	2026-07-07 07:24:24.018	2026-07-07 07:24:24.018
cmrabpkr70078nc1xxuwl0q79	ECY-303	6	t	/materiel/ctrl-ECY-303.png	t	24 VAC/DC intégrée	UI	8	OUT	8	["UI1", "UI2", "UI3", "UI4", "UI5", "UI6", "UI7", "UI8"]	["DO1", "DO2", "DO3", "DO4", "DUO5", "DUO6", "UO7", "UO8"]	f	[]	2026-07-07 07:24:24.018	2026-07-07 07:24:24.018
cmrabpkr60072nc1xrt2nq4aq	ECY-400	0	t	/materiel/ctrl-ECY-400.png	t	24 VAC/DC intégrée	UI	12	UO	12	[]	[]	f	[]	2026-07-07 07:24:24.018	2026-07-07 16:29:36.391
cmrabpkr70075nc1xrw8m2cjv	ECY-650	3	t	/materiel/ctrl-ECY-600.png	t	24 VAC/DC intégrée	UI	16	UO	14	[]	[]	t	["8UI6UO", "8UI", "16DI", "8DOR", "4UI4UO", "MBUS", "RS485"]	2026-07-07 07:24:24.018	2026-07-07 16:33:44.159
cmrabpkr70079nc1xwgx69k03	ECY-S1000E-28	7	t	/materiel/mod-controller.png	f		UI	0	UO	0	[]	[]	t	["8UI6UO", "8UI", "16DI", "8DOR", "4UI4UO", "MBUS", "RS485"]	2026-07-07 07:24:24.018	2026-07-07 16:33:44.167
cmrabpkr7007anc1x2adhbnyj	ECY-S1000E-48	8	t	/materiel/mod-controller.png	f		UI	0	UO	0	[]	[]	t	["8UI6UO", "8UI", "16DI", "8DOR", "4UI4UO", "MBUS", "RS485"]	2026-07-07 07:24:24.018	2026-07-07 16:33:44.171
cmrabpkr7007bnc1xxktog27b	ECY-S1000E-320	9	t	/materiel/mod-controller.png	f		UI	0	UO	0	[]	[]	t	["8UI6UO", "8UI", "16DI", "8DOR", "4UI4UO", "MBUS", "RS485"]	2026-07-07 07:24:24.018	2026-07-07 16:33:44.176
cmrabpkr70074nc1xuogcjpdd	ECY-600	2	t	/materiel/ctrl-ECY-600.png	t	24 VAC/DC intégrée	UI	16	UO	14	[]	[]	t	["8UI6UO", "8UI", "16DI", "8DOR", "4UI4UO", "MBUS", "RS485"]	2026-07-07 07:24:24.018	2026-07-07 16:33:44.181
\.


--
-- Data for Name: Chantier; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."Chantier" (id, nom, reference, "clientId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."Client" (id, nom, "createdAt", "updatedAt") FROM stdin;
cmr98uwgc0001821xxwwf89um	A M Chauffage	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0002821x5um0iqsq	ACTEMIUM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0003821xju11f4vl	ADICA	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0004821xn8k7kssb	AHC	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0005821xbdoy06bc	AIREO	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0006821x8wnfiqx3	AISNE EXPO	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0007821xrhyhkxkq	ALCAN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0008821xjazwlq9n	AMBROISE - AVITHERM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc0009821x75kkldum	AUCHAN HYPERMARCHE SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc000a821x9wjrpxg1	AUTOMATISME ET REGULATION	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc000b821x214mb23g	AVENIR ENERGIES	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc000c821x8fa6hjxh	BIET SASU	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgc000d821xqb8omrlb	BOUTROY R - CHARALAMBOUS G	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000e821xqkz66i9a	BOUYGUES E&S FM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000f821x9mfhtb8f	BREISTROFFER OLIVIER ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000g821xvmugrznh	BRIGAUD  ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000h821xai1j7b7l	BRUNET BONNANGE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000i821x2f82a7bp	BUCZEK	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000j821xuzlyaolh	BW PLOMBERIE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000k821x0tt8x0um	C.R.R.F J. FICHEUX ST GOBAIN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000l821x62r39ey5	CARBONNEAUX LIONEL EURL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000m821xnmxcsua2	CC du PAYS NOYONNAIS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000n821xenj8h653	CEF NORD Groupe VINCI	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000o821xsd2zr5k1	CENTRE BRUNEHAUT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000p821xljm7rkru	CENTRE HOSPITALIER CH-THIERRY	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000q821xekl953lu	CENTRE HOSPITALIER DE CHAUNY	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000r821xplptvmjf	CENTRE HOSPITALIER DE LAON	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000s821x6t54qmu9	CENTRE HOSPITALIER DE PREMONTRE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgd000t821xzgtx4gl8	CENTRE HOSPITALIER DE SAINT QUENTIN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge000u821xom5glfq2	CENTRE HOSPITALIER DE SOISSONS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge000v821xvt45chso	CK DISTRIBUTION	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge000w821xu2hfplt6	CLIMAGEL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge000x821x0pxqhth5	COFFIN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge000y821xm24k09q1	COGEBIM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge000z821x81sfn5t4	COLAS PEZERIL ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0010821x9996sqna	COMMUNE DE COUVRON AUMENANCOURT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0011821xjxpw8wf7	CONRAUX Société Nouvelle	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0012821x80tfrx0h	CONRAUX Société Nouvelle - REIMS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0013821xddpsuske	CONSEIL DEPARTEMENTAL DE L AISNE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0014821xkzhzlkj2	COPAXSO	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0015821x01lofd7p	COPIN ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0016821xipr1x4he	COPRECS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0017821x93n0agxc	CORDEVANT FREDERIC  ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0018821xq8v6lsrn	CRAM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge0019821x3njdqbvk	CUVERIE TECHNIQUE INOX	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge001a821xofelfy2y	ClientTEST	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge001b821xm40mft13	Communauté Agglo Chauny-Tergnier-La Fère	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwge001c821x4sas8mk5	DALKIA FRANCE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001d821x0yodxekv	DALKIA France AMIENS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001e821xrbug1mu1	DALKIA France CREIL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001f821x9936vehs	DALKIA France LILLE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001g821xtqf93y76	DALKIA France REIMS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001h821x7m9bzyum	DALKIA France SOISSONS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001i821xtrizndnk	DAUTREPPE Antoine	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001j821xiezy95lz	DEFRIZE SARL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001k821xlzk7gc23	DEHAN SEBASTIEN  ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001l821x747wl5xn	DEJARDIN FABRICE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001m821xdl0r7rdp	DELAFONT ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001n821xiqeks3yd	DELANNOY DEWAILLY	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001o821xqk49vucj	DELFORGE BACLET EURL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001p821xaogwwc3q	DESSAINT SN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001q821xlb8y4b6h	DESSEY DAVID SARL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001r821xrlvnnxcz	DONAT ENT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001s821x46zrw88w	DSP SA	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001t821x5y0hb07t	DUPONT CHAUFFAGE SERVICES	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001u821xaj3uubez	E.C.R ELECTRICITE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001v821xh9x9y6u9	EAISNER	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001w821x8e6ax1vv	EDEF LAON	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgf001x821xdbp0ac09	EIFFAGE ENERGIE SYSTEMES	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg001y821x1o84k3wl	EMI GENIE CLIMATIQUE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg001z821xyigtsih8	ENGIE ENERGIE REIMS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0020821x5fvm427l	ENGIE ENERGIE SERVICES AISNE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0021821xv8fiokde	ENGIE ENERGIE SERVICES ARRAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0022821xybwpqiee	ENGIE ENERGIE SERVICES Beauvais	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0023821xe84afnrt	ENGIE ENERGIE SERVICES LILLE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0024821x3lha40sw	ENGIE ENERGIE SERVICES OISE Est	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0025821xigx0xoh2	ENGIE ENERGIE SERVICES SOMME	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0026821xc2ml1qm0	ENGIE ENERGIE SERVICES TROYES	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0027821x55rjekyy	ENGIE HOME SERVICES BRUYERES ET MONTBERAULT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0028821xbmbjddkp	ENGIE HOME SERVICES ST QUENTIN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg0029821xisc89x3i	ENGIE HOME SERVICES VILLENEUVE ST GERMAIN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002a821xnlzwm1x4	ENGIE RESEAUX Reims - SOCCRAM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002b821xcd86v8hu	EPHESE LIESSE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002c821x4lkhw8em	ESSIQUE P. SA	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002d821x8mv0yv2p	Eiffage Energie Systemes - Lorraine	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002e821xyay9wtza	FAPAGAU ET CIE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002f821x3rqizach	FAVEREAUX	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002g821xlw647q4a	FERNANDES ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002h821x8e594apc	FLAMANT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002i821xdw06zz4a	FLAMME BLEUE STE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002j821xmui6oj0m	FOYER DE BETHANCOURT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002k821x5i6wvzt4	FRANCOIS AURELIEN  ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002l821x02t321dr	FRIGITEC	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002m821xr9pr3fsn	GAYET ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002n821x4xqrh034	GENDARMERIE MOBILE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002o821xggw33sml	GONTHIER ARMAND ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002p821xtubru0ef	GROUPE ROBERT SCHUMAN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002q821xmnoskbcg	GUERY Erwan	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002r821xzdhscxtb	HELA SARL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002s821xmw1jjbgs	HERVE-THERMIQUE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002t821xf28o82nd	HOFLACK CHAUFFAGE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgg002u821xruehsggp	HOORNAERT FABRICE ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh002v821xf71cbzsd	HOULLE ARDENNES S.A.	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh002w821xizm1k1mz	I P H	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh002x821xp22xhahb	IDEX ENERGIES - Groupe IDEX	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh002y821xmry79dro	IDEX ENERGIES REIMS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh002z821xyj9w7zi2	INSTITUT MEDICO EDUCATIF SPECIALISE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0030821xagn0f7j3	JM FROID	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0031821xqmnxi8rj	K.V.E.I	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0032821xrtrsjrzk	KOCH Société Nouvelle - Groupe FARENEIT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0033821xt74d5nub	L.C.FROID ET CLIM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0034821xe63a5suz	LA BUL - BASE URBAINE DE LOISIRS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0035821xj44b1gli	LA LOUISIANE S.A	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0036821xytwurutl	LACOUR MONTAY PAINVIN SARL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0037821xielzny3n	LE CAMUS Entreprise	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0038821xkzvl3k4u	LEGRAND DANIEL ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh0039821xjbkrhmt8	LES PRESSOIRS COQUARD	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003a821xopx39xe6	LOCHERON JOEL SA	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003b821x3t5nk75n	LOGITRADE SA	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003c821xyb7bbcjh	LOU ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003d821x8ol4r6io	MAG SAS - CHARRUES DEMBLON	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003e821xhy3imk0h	MAGUIN SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003f821xel3h0grt	MAINTENANCE BOBINAGE INDUSTRIEL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003g821x2u1433wz	MAISON DE RETRAITE DEP. DE L AISNE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003h821xkuy55rxx	MAISON RETRAITE VERVINS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003i821xcv9fypva	MATRA ELECTRONIQUE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003j821xcklydvn0	MAUPRIVEZ ENT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003k821x49wqka0m	MCI SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003l821xiftjm1om	MCT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003m821xdfzkot08	MISSENARD CLIMATIQUE 59	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003n821xbyupbxu1	MISSENARD CLIMATIQUE AMIENS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003o821xycayt1fq	MISSENARD CLIMATIQUE ARRAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003p821xar3uxwpj	MISSENARD CLIMATIQUE BEAUVAIS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003q821xamcc70ja	MISSENARD CLIMATIQUE HC	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003r821x6wgylkfc	MISSENARD CLIMATIQUE INSTALL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003s821xgfhtfr6g	MISSENARD CLIMATIQUE REIMS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003t821xs8p9wtrh	MISSENARD CLIMATIQUE SOISSONS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003u821xenfneqmv	MISSENARD CLIMATIQUE ST QUENTIN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003v821xrwt8itj6	MONSEGU S A	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003w821x9c00shjk	MORELLE Ets	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003x821xjlaw44z6	MORIN WANDERPEPEN S.A.S	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgh003y821xud9b5tzn	MORLET EPERNAY SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi003z821x4jnrjis2	N'THERMIQUE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0040821x07tqlupr	NESTLE FRANCE ITANCOURT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0041821xza45mj73	NLMK Coating S.A.	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0042821xcb8vpf1o	NOIROT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0043821xkkde3q0a	NORD EST CLIMATIC	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0044821x3s6bvqfl	P C P V	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0045821x7hfrolco	PARTICULIER	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0046821xhidvlm33	PERSINET FABIAN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0047821xtaktwcm2	PHIDEL SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0048821xj9knwqt2	PLANETE AZUR	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0049821xhdf1m93m	POINT CHAUFFAGE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004a821x5tc52g1m	POULAIN SARL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004b821xhdfk2hks	PRO	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004c821xuuf6jqz5	Passion Malts Concepts	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004d821x353map7c	R'Elec	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004e821xp83dq7wk	RHODIA OPERATIONS SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004f821x04k0h11z	RSC VISERY SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004g821xhah0xiz4	Région Hauts-de-France	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004h821xgyialote	S G I	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004i821xmazxx5s0	S.D.R 60	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004j821xx2m2hdsy	S.T.I.	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004k821xdfszim97	S.T.I.O	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004l821x1cyekbde	SANICONFORT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004m821x9qf63msr	SARDA WETISCHECK  ENT	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004n821xzglhhhhl	SCOP	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004o821xeso3j6m7	SEIBO	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004p821x9heynqsx	SERIP SAS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004q821xklj2u3tu	SERVICE TECHNIQUE CHAUNY	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004r821xqfpp2sad	SISTEM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004s821x0bohffb4	SOREM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004t821xbj470txl	SORETHERM PICARDIE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004u821x6j38q2gj	STIO	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004v821xlz37uv0n	T.R. EQUIPEMENTS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004w821xxj2ks06w	TATA STEEL FRANCE Bâtiments et Systèmes	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004x821x8aqggn7v	TCAP ENERGIE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004y821xa4wxcu8o	TESTE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi004z821xllmpzoom	THERMACLIM - AVITHERM	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0050821xs9dy5i4i	THERMOTEC SERVICES	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0051821xwvut2ywe	USEDA	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0052821xxrsrc9x0	VAUVILLE - SARL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0053821xh0tnfr93	VAZ THERMIC	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgi0054821xrnyypo25	VILLE DE GUISE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj0055821xa81pnx6c	VILLE DE LAON	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj0056821xjeq07szw	VILLE DE TERGNIER	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj0057821x27p8u14r	VILLEVOYE SARL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj0058821x5fvyj8sa	VILLIERS DEPANNAGE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj0059821xp4c3tz1p	VINCI LILLE	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj005a821xuir94ghm	WEST PHARMACEUTICAL	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj005b821x3ig89iud	WILLIAM SAURIN	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj005c821xk8j2k8ro	WOJEWODKA ETS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
cmr98uwgj005d821xbn0ovmt2	XAVIER PERE ET FILS	2026-07-06 13:16:47.436	2026-07-06 13:16:47.436
\.


--
-- Data for Name: Modele; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."Modele" (id, nom, ordre, points, "createdAt", "updatedAt") FROM stdin;
cmraxg8ti00721o1xnbbf40az	Généralité	0	[{"nom": "Sonde extérieur", "type": "AI"}, {"nom": "Sonde départ primaire", "type": "AI"}, {"nom": "Sonde Retour", "type": "DI"}, {"nom": "Defaut Manque Eau", "type": "DI"}, {"nom": "Defaut Manque Gaz", "type": "DI"}, {"nom": "Defaut Manque Tension", "type": "DI"}, {"nom": "Defaut pompe de relevage", "type": "DI"}]	2026-07-07 17:33:00.198	2026-07-07 17:33:00.198
cmraxg8ti00731o1xlcq1kkiw	Circuit Régulé	1	[{"nom": "Sonde départ", "type": "AI"}, {"nom": "Sonde Retour", "type": "DI"}, {"nom": "Sonde ambiance", "type": "AI"}, {"nom": "Sonde ambiance Ss Fil", "type": "COM"}, {"nom": "Commande Vanne 3 voies", "type": "AO"}, {"nom": "Commande pompe 1", "type": "DO"}, {"nom": "Commande pompe 2", "type": "DO"}, {"nom": "Defaut pompe 1", "type": "DI"}, {"nom": "Defaut pompe 2", "type": "DI"}, {"nom": "Compteur Mbus", "type": "COM"}]	2026-07-07 17:33:00.198	2026-07-07 17:33:00.198
cmraxg8ti00741o1xnonbg1zt	ECS	2	[{"nom": "Sonde départ", "type": "AI"}, {"nom": "Sonde retour", "type": "AI"}, {"nom": "Commande Pompe primaire ECS", "type": "DO"}, {"nom": "Defaut ECS", "type": "DI"}, {"nom": "Defaut Pompe bouclage 1", "type": "DI"}, {"nom": "Defaut Pompe bouclage 2", "type": "DI"}, {"nom": "Defaut Pompe primaire ECS", "type": "DI"}]	2026-07-07 17:33:00.198	2026-07-07 17:33:00.198
cmraxg8ti00751o1x3gxeysv6	Chaudiere	3	[{"nom": "Sonde départ chaudiere 1", "type": "AI"}, {"nom": "Sonde départ chaudiere 2", "type": "AI"}, {"nom": "Commande chaudiére 1", "type": "AO"}, {"nom": "Commande chaudiére 2", "type": "AO"}, {"nom": "Defaut chaudière 1", "type": "DI"}, {"nom": "Defaut chaudière 2", "type": "DI"}, {"nom": "Commande Vanne 2 voies", "type": "DO"}, {"nom": "Commande Vanne 2 voies", "type": "DO"}, {"nom": "Capteur pression", "type": "AI"}]	2026-07-07 17:33:00.198	2026-07-07 17:33:00.198
cmraxg8ti00761o1x9km9w5m3	CTA	4	[{"nom": "Commande Moteur Air Soufflé", "type": "AO"}, {"nom": "Défaut Moteur Air Soufflé", "type": "DI"}, {"nom": "Défaut Débit Air Soufflé", "type": "DI"}, {"nom": "Sonde Air Soufflé", "type": "AI"}, {"nom": "Commande Moteur Air Repris", "type": "AO"}, {"nom": "Défaut Moteur Air Repris", "type": "DI"}, {"nom": "Défaut Débit Air Repris", "type": "DI"}, {"nom": "Sonde Air Repris", "type": "AI"}, {"nom": "Sonde Après Echangeur", "type": "AI"}, {"nom": "Commande Vanne Chaud", "type": "AO"}, {"nom": "Commande Vanne Froid", "type": "AO"}, {"nom": "Pressostat Filtre d'Air Neuf", "type": "DI"}, {"nom": "Pressostat Filtre d'Air Repris", "type": "DI"}, {"nom": "Sonde Air Neuf", "type": "AI"}, {"nom": "Commande registre Air Neuf", "type": "AO"}, {"nom": "Commande registre Air Soufflé", "type": "AO"}, {"nom": "Commande registre Air Regeté", "type": "AO"}]	2026-07-07 17:33:00.198	2026-07-07 17:33:00.198
\.


--
-- Data for Name: ModuleModele; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."ModuleModele" (id, type, ordre, actif, image, categorie, "entreeKind", "entreeCount", "sortieKind", "sortieCount", "createdAt", "updatedAt") FROM stdin;
cmrabpkrp007cnc1x9k46qbix	8UI6UO	0	t	/materiel/mod-8UI6UO.png	extension	UI	8	UO	6	2026-07-07 07:24:24.037	2026-07-07 07:24:24.037
cmrabpkrp007dnc1x04qqwg3s	8UI	1	t	/materiel/mod-8UI.png	extension	UI	8	UO	0	2026-07-07 07:24:24.037	2026-07-07 07:24:24.037
cmrabpkrp007enc1xrp8e9zeu	16DI	2	t	/materiel/mod-16DI.png	extension	DI	16	DO	0	2026-07-07 07:24:24.037	2026-07-07 07:24:24.037
cmrabpkrp007fnc1xzwgwrhro	8DOR	3	t	/materiel/mod-8DOR.png	extension	DI	0	DO	8	2026-07-07 07:24:24.037	2026-07-07 07:24:24.037
cmrabpkrp007hnc1xyqmq4usa	MBUS	5	t	/materiel/mod-MBUS.png	communication		0		0	2026-07-07 07:24:24.037	2026-07-07 07:24:24.037
cmrabpkrp007inc1xl187pljx	RS485	6	t	/materiel/mod-RS485.png	communication		0		0	2026-07-07 07:24:24.037	2026-07-07 07:24:24.037
cmrabpkrp007jnc1x21t0315u	SCREEN	7	t		accessoire		0		0	2026-07-07 07:24:24.037	2026-07-07 07:24:24.037
cmrabpkrp007gnc1x4rzifael	4UI4UO	4	t	/materiel/mod-4UI4UO.png	extension	UI	4	UO	4	2026-07-07 07:24:24.037	2026-07-07 16:35:52.731
\.


--
-- Data for Name: PointCatalog; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."PointCatalog" (id, nom, type, "createdAt") FROM stdin;
cmr98w2uh005e4f1xx4usfvlx	Capteur pression	AI	2026-07-06 13:17:42.377
cmr98w2uh005f4f1x2z8ithqd	Commande	DO	2026-07-06 13:17:42.377
cmr98w2uh005g4f1x953nvo7t	Commande chaudiére 1	AO	2026-07-06 13:17:42.377
cmr98w2uh005h4f1xm8uem9u4	Commande chaudiére 2	AO	2026-07-06 13:17:42.377
cmr98w2uh005i4f1xamh0dp0p	Commande pompe 1	DO	2026-07-06 13:17:42.377
cmr98w2uh005j4f1x7sd868rf	Commande pompe 2	DO	2026-07-06 13:17:42.377
cmr98w2uh005k4f1xss80k1r6	Commande Pompe primaire ECS	DO	2026-07-06 13:17:42.377
cmr98w2uh005l4f1xd6ivxdu8	Commande Vanne 2 voies	DO	2026-07-06 13:17:42.377
cmr98w2uh005m4f1x9sstztuy	Commande Vanne 3 voies	AO	2026-07-06 13:17:42.377
cmr98w2uh005n4f1xtrdgmfck	Compteur Impulsion	DI	2026-07-06 13:17:42.377
cmr98w2uh005o4f1xwe1j7msi	Compteur Mbus	COM	2026-07-06 13:17:42.377
cmr98w2uh005p4f1x814wb7w8	Compteur Modbus	COM	2026-07-06 13:17:42.377
cmr98w2uh005q4f1xiu9dxgd0	Defaut	DI	2026-07-06 13:17:42.377
cmr98w2uh005r4f1xhp3qw3gj	Defaut chaudière 1	DI	2026-07-06 13:17:42.377
cmr98w2uh005s4f1x1h9drudb	Defaut chaudière 2	DI	2026-07-06 13:17:42.377
cmr98w2uh005t4f1x1r8blg5s	Defaut ECS	DI	2026-07-06 13:17:42.377
cmr98w2uh005u4f1xl0vls7u9	Defaut Manque Eau	DI	2026-07-06 13:17:42.377
cmr98w2uh005v4f1xxcnoczix	Defaut Manque Gaz	DI	2026-07-06 13:17:42.377
cmr98w2uh005w4f1x29nr3pcf	Defaut Manque Tension	DI	2026-07-06 13:17:42.377
cmr98w2uh005x4f1xjp4w7gpu	Defaut pompe 1	DI	2026-07-06 13:17:42.377
cmr98w2uh005y4f1xo6x79mz2	Defaut pompe 2	DI	2026-07-06 13:17:42.377
cmr98w2uh005z4f1xfnas4gqb	Defaut Pompe bouclage 1	DI	2026-07-06 13:17:42.377
cmr98w2uh00604f1x67ppf5zd	Defaut Pompe bouclage 2	DI	2026-07-06 13:17:42.377
cmr98w2uh00614f1xde25qyc4	Defaut pompe de relevage	DI	2026-07-06 13:17:42.377
cmr98w2uh00624f1xx8mktbdx	Defaut Pompe primaire ECS	DI	2026-07-06 13:17:42.377
cmr98w2uh00634f1xk4spkdyk	Pilotage	AO	2026-07-06 13:17:42.377
cmr98w2uh00644f1x8ofopuld	Pressostat d'air	DI	2026-07-06 13:17:42.377
cmr98w2uh00654f1xfs3wysgw	Retour marche	DI	2026-07-06 13:17:42.377
cmr98w2uh00664f1x69ctmzpt	Sonde ambiance	AI	2026-07-06 13:17:42.377
cmr98w2uh00674f1xrgvsp8m8	Sonde ambiance Ss Fil	COM	2026-07-06 13:17:42.377
cmr98w2uh00684f1x4c1xfe5d	Sonde CO2	AI	2026-07-06 13:17:42.377
cmr98w2ui00694f1xoh0ewy3d	Sonde départ	AI	2026-07-06 13:17:42.377
cmr98w2ui006a4f1xswsqs7q9	Sonde départ chaudiere 1	AI	2026-07-06 13:17:42.377
cmr98w2ui006b4f1xomwj4tla	Sonde départ chaudiere 2	AI	2026-07-06 13:17:42.377
cmr98w2ui006c4f1xgrgg8s6r	Sonde départ primaire	AI	2026-07-06 13:17:42.377
cmr98w2ui006d4f1xmdiojkvw	Sonde extérieur	AI	2026-07-06 13:17:42.377
cmr98w2ui006e4f1xmcgtjegc	Sonde reprise	AI	2026-07-06 13:17:42.377
cmr98w2ui006f4f1xbkn09tj6	Sonde retour	AI	2026-07-06 13:17:42.377
cmr98w2ui006g4f1x5t2vh75a	Sonde soufflage	AI	2026-07-06 13:17:42.377
cmr98w2ui006h4f1xhgukllaf	Securite Plancher Chauffant	DI	2026-07-06 13:17:42.377
cmr98w2ui006i4f1xpvy48p8o	Compteur Gaz Sans Fils	AO	2026-07-06 13:17:42.377
cmr98w2ui006j4f1xnn4ry4ps	Compteur Eau Sans Fils	AO	2026-07-06 13:17:42.377
cmr98w2ui006k4f1xlvgrtpe7	Compteur Electrique Sans Fils	AO	2026-07-06 13:17:42.377
cmr98w2ui006l4f1xj8hf0qef	Commande Moteur Air Soufflé	AO	2026-07-06 13:17:42.377
cmr98w2ui006m4f1xwe2mzwe5	Défaut Moteur Air Soufflé	DI	2026-07-06 13:17:42.377
cmr98w2ui006n4f1x1phuxyel	Défaut Débit Air Soufflé	DI	2026-07-06 13:17:42.377
cmr98w2ui006o4f1x0nzzce7j	Sonde Air Soufflé	AI	2026-07-06 13:17:42.377
cmr98w2ui006p4f1xaundretg	Commande Moteur Air Repris	AO	2026-07-06 13:17:42.377
cmr98w2ui006q4f1xa5zs3qhv	Défaut Moteur Air Repris	DI	2026-07-06 13:17:42.377
cmr98w2ui006r4f1xuj5leeo9	Défaut Débit Air Repris	DI	2026-07-06 13:17:42.377
cmr98w2ui006s4f1xq2oi7is9	Sonde Air Repris	AI	2026-07-06 13:17:42.377
cmr98w2ui006t4f1xoq7c0g7o	Sonde Après Echangeur	AI	2026-07-06 13:17:42.377
cmr98w2ui006u4f1x7cg1mbuq	Commande Vanne Chaud	AO	2026-07-06 13:17:42.377
cmr98w2ui006v4f1xym2sr6ae	Commande Vanne Froid	AO	2026-07-06 13:17:42.377
cmr98w2ui006w4f1xmygxglpc	Pressostat Filtre d'Air Neuf	DI	2026-07-06 13:17:42.377
cmr98w2ui006x4f1xjpzz82nj	Pressostat Filtre d'Air Repris	DI	2026-07-06 13:17:42.377
cmr98w2ui006y4f1xywve3dr6	Sonde Air Neuf	AI	2026-07-06 13:17:42.377
cmr98w2ui006z4f1xskxb2j3c	Commande registre Air Neuf	AO	2026-07-06 13:17:42.377
cmr98w2ui00704f1xz54m6uu1	Commande registre Air Soufflé	AO	2026-07-06 13:17:42.377
cmr98w2ui00714f1xkeidrc0p	Commande registre Air Regeté	AO	2026-07-06 13:17:42.377
\.


--
-- Data for Name: PointsList; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."PointsList" (id, titre, "clientNom", "chantierNom", date, rows, "createdById", "createdAt", "updatedAt", "clientId", "numeroWhy") FROM stdin;
cmr9k01ek0001h31x5up4kul8	[DEMO] Cuisine centrale — Laon	ENGIE ENERGIE SERVICES SOMME	Cuisine centrale — Laon	2026-05-30 18:28:42.907	[{"id": "8aded5c9-d788-4746-acb2-6b299068ef17", "nom": "Généralité", "kind": "section"}, {"id": "3cefe177-d38d-4063-998f-a03f3db9fa4e", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "1767ea5d-274c-4ae8-a73f-91a21fbf140d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "f187fc25-223f-4241-ba8d-1b79add752fc", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "d049184b-cae0-4538-aef5-352ad8469608", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "0d817cda-293f-4b6c-86c5-03963f91e39b", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "17ebc570-4fd5-46a1-971e-e2622f801af5", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "88c23d97-d2be-4171-9532-3c7093e40f69", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "eea0faaf-aacc-4999-8e35-88e5b9badbd5", "nom": "Chaudiere", "kind": "section"}, {"id": "c81d4ed3-4c14-4813-b848-6960f22d6584", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 1", "kind": "point"}, {"id": "4e3b54fe-df9f-4ed1-83ee-8c99b6f3fada", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 2", "kind": "point"}, {"id": "f7d3718a-433d-422c-a473-7c0fff40bddd", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 1", "kind": "point"}, {"id": "46cd24e0-f289-4644-81bb-800e151dcd85", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 2", "kind": "point"}, {"id": "b6598a91-d746-4620-8b94-bf0af41c1817", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 1", "kind": "point"}, {"id": "3824cd64-045c-433e-b11c-7ae3418048ca", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 2", "kind": "point"}, {"id": "37a07d6e-d25e-45b1-b74c-2724aff9e6ac", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "c8194425-c23b-4898-9ef4-ecde52c812bf", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "c92b3425-3902-40da-899e-4f6e2673112c", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Capteur pression", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.908	2026-07-06 18:40:30.404	cmr98uwgg0025821xigx0xoh2	\N
cmr9k01ed0000h31xv28lgfz2	[DEMO] Mise aux normes GTB — Chauny	WEST PHARMACEUTICAL	Mise aux normes GTB — Chauny	2025-10-24 18:28:42.892	[{"id": "6352a19c-f468-41d3-96dc-0921271bc24a", "nom": "Généralité", "kind": "section"}, {"id": "51c080ff-cd10-4b92-803c-17a6c327f325", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "464e90a2-d682-49d1-b0bf-01246a29d855", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "b0962cd4-4805-4022-ad00-f104dc8046fe", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "675b1e29-d50d-422a-82e5-a1ff68140ecc", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "69be2675-02c4-4a61-adce-7e3cfe39a3f5", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "ae1c0b15-5a5f-496d-8808-925c651baadd", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "3aa82ec6-4645-4bd3-bf96-aee765af785f", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "c45ef97e-156f-4bb1-a502-a4355b8d77b1", "nom": "Chaudiere", "kind": "section"}, {"id": "41c3b24f-80de-4f7f-a91d-249b30613fed", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 1", "kind": "point"}, {"id": "c4ad1b61-9a0c-48ad-98a5-289450fcbaf2", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 2", "kind": "point"}, {"id": "34589e1c-f903-408b-a9d2-f24043950a1c", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 1", "kind": "point"}, {"id": "52112c3a-fd9b-480d-a611-9de302b05709", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 2", "kind": "point"}, {"id": "710502c6-e381-49dd-88c8-b77e68448343", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 1", "kind": "point"}, {"id": "09cf689f-2a3c-42ae-9904-48c1abcdbda7", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 2", "kind": "point"}, {"id": "ad40c913-d457-4cde-8a80-3c988ae748af", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "66521cb3-9f49-47a2-84c8-86f1b8cd9735", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "a7a30624-70bc-4ae2-bffc-8b64bb1337a1", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Capteur pression", "kind": "point"}, {"id": "c6a72921-0a69-4728-8e64-1222471cd0ad", "nom": "Circuit Régulé", "kind": "section"}, {"id": "d51ec927-e56c-44f6-b02e-8b368dcbab4b", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "b9eeab4a-9fe4-4b8c-9353-7d21b8d5b337", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "988cc554-a53e-4187-b25e-f2a8499416e9", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "947c495a-0ff1-45fd-b878-efb0038c4f5d", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "8f8ff0d2-4c75-4dc3-a7a3-8ce9e5a9bf0d", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "d199cc17-b965-4c16-b999-6cbfe9a320ff", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "55489b73-b8bb-4788-a906-1888c584c75d", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "1b6388b8-6b0f-4405-8f27-4be814d29a98", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "90fb705c-80b5-4603-a93c-84ea573f70ca", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "e4d53bae-cb84-4f3b-b258-0d35842b8c5e", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}, {"id": "8ec22719-dc66-4b39-afa3-e9ae4591e12a", "nom": "ECS", "kind": "section"}, {"id": "08512def-7284-4bc5-bc2a-4c1255ab329e", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "de8b37cf-1f43-4592-bd1c-da1ef4c69601", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde retour", "kind": "point"}, {"id": "e6fc1ae9-79fd-4ba6-8c5b-dad419ad21a7", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Pompe primaire ECS", "kind": "point"}, {"id": "910c0ad9-4b97-4b63-a951-f5c36959d26b", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut ECS", "kind": "point"}, {"id": "ee7c386c-642a-4d02-8ed2-9561cdbf75c7", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 1", "kind": "point"}, {"id": "ee3f528a-c9af-4f39-8644-cbbb1947a4c5", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 2", "kind": "point"}, {"id": "30ca8890-440c-4931-8169-79fefe1b0451", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe primaire ECS", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.901	2026-07-06 18:40:30.397	cmr98uwgj005a821xuir94ghm	\N
cmraa33m10002n71xzs4ud2mc	\N			2026-07-07 00:00:00	[{"id": "3593ac6c-1223-4ab8-b405-ebee51c6ac4b", "nom": "Généralité", "kind": "section"}]	cmr97nnti0000151x5566cx94	2026-07-07 06:38:55.753	2026-07-07 06:38:56.736	\N	\N
cmr9k5jlx0004lj1xd1qb0u0h	\N	ADICA	TEST GUS	2026-07-06 00:00:00	[{"id": "78f193af-255f-4a41-be6f-7b307506d9e8", "nom": "Circuit Régulé", "kind": "section"}, {"id": "5bee668a-a7f6-41bd-a509-24b87b9ead6b", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point", "note": ""}, {"id": "cad6debd-bc08-4eb1-b520-653b4cd6357d", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point", "note": ""}, {"id": "3f8f136b-a105-4503-87bd-0976a5c23f29", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point", "note": ""}, {"id": "0868c7e6-94cd-465f-9bb3-e00bfa0daac5", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point", "note": ""}, {"id": "79d520d7-7d12-40b4-a20e-3285ecffd9a3", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point", "note": ""}, {"id": "c4dcd76a-f987-434e-b22c-cb181906c3b8", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point", "note": ""}, {"id": "18f31a81-ebce-4627-a452-03c8bb536da8", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point", "note": ""}, {"id": "da0b82f3-19e7-48d1-a446-e1cb2d6230d5", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point", "note": ""}, {"id": "0f108994-1640-4572-b925-cde499256082", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point", "note": ""}, {"id": "d4287f23-7b34-4ea9-9746-b96ec004aa59", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point", "note": ""}, {"id": "436b637f-a3a6-471b-8c10-af6587e2b5c3", "nom": "Chaudiere", "kind": "section"}, {"id": "c148c2d7-068e-46d1-973c-bcaadb5e201f", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 1", "kind": "point", "note": ""}, {"id": "04b72487-66d9-4818-8400-85590de84880", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 2", "kind": "point", "note": ""}, {"id": "5c1659cb-1432-4716-94c0-d901d670a24a", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 1", "kind": "point", "note": ""}, {"id": "65764a70-b5b9-457d-9fb2-225474175f77", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 2", "kind": "point", "note": ""}, {"id": "36c8ca62-7044-44b6-b4bc-142621e1549a", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 1", "kind": "point", "note": ""}, {"id": "a2c7c989-9d71-4745-8da7-7a2c5263b701", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 2", "kind": "point", "note": ""}, {"id": "f14be8f9-bc0d-47c8-aec4-397b7911ceeb", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point", "note": ""}, {"id": "7b0e2381-1b3e-4f42-93ac-2d605687a4ad", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point", "note": ""}, {"id": "cf986779-2ad4-4c05-8918-7ebd9ea04f19", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Capteur pression", "kind": "point", "note": ""}, {"id": "790972ce-d593-4ca5-a7a7-63213a1d6e22", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "", "kind": "point", "note": ""}]	cmr97nnti0000151x5566cx94	2026-07-06 18:32:59.781	2026-07-07 06:39:26.509	cmr98uwgc0003821xju11f4vl	\N
cmr9k01ep0002h31x5te0hr5n	[DEMO] Atelier — Chauny	SARDA WETISCHECK  ENT	Atelier — Chauny	2025-09-04 18:28:42.912	[{"id": "1e339979-2c3e-47a4-964d-6ee832f65f2f", "nom": "Circuit Régulé", "kind": "section"}, {"id": "821cea08-b78b-4353-adcb-00c9fa5274dc", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "5a31e39e-139c-433e-85a1-e0775fe8b901", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "6b4602b4-6119-42e8-b86c-69ffe739be7f", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "702610aa-b8e5-4890-8c74-b3783c301775", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "c5eaea08-8a91-45e6-9fb8-efd20a8682d5", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "2beab0bf-69bc-4cc9-9393-9960cca606b1", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "efa55a9e-9697-4857-9d24-1676ab222496", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "837817c9-a657-47ec-acff-01bdf86ed09a", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "86e85b20-fb05-4b06-9646-9c100492be67", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "0e7e5cba-e1c0-4be4-811b-7a7c0f1db81d", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}, {"id": "5fcf2d6d-ee34-4537-ac44-4b4496a152c1", "nom": "Généralité", "kind": "section"}, {"id": "098ea3fe-09b0-4343-b6fd-3e72040bbb97", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "dacec423-c4b7-4999-a934-a800af0123a0", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "02832ec3-f052-43a3-af01-cc1987f3c845", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "cbf277b4-d555-4311-a88d-240c3a2b486e", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "59722337-da6a-4302-a43c-f06d6bb39e40", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "d02201ad-7d1f-402d-b33e-e35d5cdf976c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "c968fe82-9247-48dc-af86-b5ddae7a28d0", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "8d8f7e74-c13f-4a4c-9732-6d773110e190", "nom": "ECS", "kind": "section"}, {"id": "aadcac59-1865-47dd-b031-74a9322ea4b4", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "399ec26c-992a-4339-b59f-d8f09ab47fa3", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde retour", "kind": "point"}, {"id": "cd91f3dc-96a6-434a-860c-67298fb05cd0", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Pompe primaire ECS", "kind": "point"}, {"id": "676da0bf-0df1-4c79-b3d3-661dea80f945", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut ECS", "kind": "point"}, {"id": "b607d5bf-c174-4c4b-97b1-54e47275ce49", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 1", "kind": "point"}, {"id": "272dc493-4fde-489a-ad99-4b4568000dea", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 2", "kind": "point"}, {"id": "d2aa1fb2-4a6c-46a8-8d49-1cb6430e44ad", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe primaire ECS", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.913	2026-07-06 18:40:30.41	cmr98uwgi004m821x9qf63msr	\N
cmr9k01eu0003h31xcxeovzom	[DEMO] Cuisine centrale — Soissons	VAUVILLE - SARL	Cuisine centrale — Soissons	2026-07-02 18:28:42.917	[{"id": "ac47a1d0-ff0c-4da3-9c86-c8974f1470a8", "nom": "Généralité", "kind": "section"}, {"id": "1a98bc63-cc84-45b5-9a68-6a19260e5974", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "c5e99723-6c04-4e0f-9103-8aa17bec732e", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "265e0630-2afa-4763-8a42-04fb8f278b6c", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "17e95969-2eac-4493-8f81-6f9c44906192", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "03a568ab-4a5a-47f6-a0e8-b8dee53cffa3", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "7f6e2c5a-e2ef-47a6-9baa-f325396d107e", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "87d55e70-3518-4e20-8601-724991276488", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "7aedfb43-85e5-423e-8ee2-952bff6d9e47", "nom": "Chaudiere", "kind": "section"}, {"id": "a5f73d1f-2b0e-4ba3-9f77-d3bf3cc9b54b", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 1", "kind": "point"}, {"id": "6df92835-a6ab-42a2-bdac-8da0e4641b09", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 2", "kind": "point"}, {"id": "0b629a9a-6b75-424d-96c0-81846995f22b", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 1", "kind": "point"}, {"id": "7ff76985-be7a-45fd-8b13-ecc94077e425", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 2", "kind": "point"}, {"id": "dec35bd3-54cf-4a8f-a31b-1ec893bb5373", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 1", "kind": "point"}, {"id": "1fc6f1ef-7a1b-45dc-9e4f-85f1a0679ddd", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 2", "kind": "point"}, {"id": "222b7311-de15-401c-a314-414a1a6ff69f", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "753b7b1b-0a8a-402d-803d-c72ab73956f3", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "0648e20d-4f78-4aa0-a683-ba7b624cbfbd", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Capteur pression", "kind": "point"}, {"id": "2eee5810-a2a3-4c51-a8b7-e7d164b53498", "nom": "Circuit Régulé", "kind": "section"}, {"id": "889df5ba-702b-4fef-9a70-5496f46da9e8", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "7520de1e-2d16-42f0-832e-c56fecb2f3de", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "aa80ab34-787d-4c31-b4cb-6dce1e92a351", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "7dbb6733-5419-451b-92c8-9f6921437741", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "12824c72-5abf-44c5-aca3-1cc93c150ee6", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "ec92f732-a323-4943-b4b1-ddf135985645", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "2ea3f5de-e4e6-422b-bf39-7e7b41e7109a", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "c6ae989a-a9e2-40bc-b3e1-39fa7c8d0ac2", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "0e0374f8-0ba6-4c0d-b5de-39ccf453e6d1", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "9b7ce149-6732-488b-ab6f-ce2b7e0f1e6d", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}, {"id": "b314123d-e01c-41e6-992f-49ad1c6f6d96", "nom": "ECS", "kind": "section"}, {"id": "a400befd-7ce3-48be-b728-300342ffad8f", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "e23959e7-f43d-431e-b2ca-33265566ff37", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde retour", "kind": "point"}, {"id": "7b7c1a01-b576-42b8-8de1-d82e4ccc32fc", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Pompe primaire ECS", "kind": "point"}, {"id": "5a945828-73ef-477f-a35d-d2dd17a39f9c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut ECS", "kind": "point"}, {"id": "ee52ee63-ce31-4e8c-aa24-33fc0d902584", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 1", "kind": "point"}, {"id": "2f65f9dc-5e51-4c3f-afd8-81ead11522f2", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 2", "kind": "point"}, {"id": "4ca4a6cd-e3e1-48b5-ae73-dee2ceff30c9", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe primaire ECS", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.918	2026-07-06 18:40:30.417	cmr98uwgi0052821xxrsrc9x0	\N
cmr9k01ez0004h31x0q3d9htq	[DEMO] Gymnase — Château-Thierry	CLIMAGEL	Gymnase — Château-Thierry	2025-10-17 18:28:42.922	[{"id": "8d89baa0-8f73-4c57-bbff-d2e71c489762", "nom": "Généralité", "kind": "section"}, {"id": "0109fdab-1a14-444c-a81f-96774bfae9e7", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "e19e61dd-a381-4a98-9257-2b8298998aac", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "e8b45396-907d-4002-9378-cc9084f68dd9", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "0a41cfb9-e9a4-45b4-b000-6ce3f949a83c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "a700dda5-eb5a-44a2-84f9-ce7478f9b470", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "e9c25632-7fbf-4bdf-8724-11861805efd7", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "e8089ef7-15ce-4545-8594-25b41bfdc5f7", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "c8dee9fa-cff5-4c12-ab57-14b366dbcab7", "nom": "Circuit Régulé", "kind": "section"}, {"id": "69391fd3-9c01-48f8-bef4-0162c468ca79", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "519995d2-e9df-4f67-8ba2-c040f343fc87", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "210b8d25-afbf-4e41-ac20-5c09d9f6a2b4", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "a2d6f782-c4c0-41cd-b8cc-df2e1e467a57", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "cc81489a-a1f1-4db5-8648-6ef4376fbc58", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "9fb23d7a-3166-4154-a277-e57cbeffe0a0", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "707e7430-93b4-40f9-8d75-062956dd9e5e", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "e7c951c4-9838-4ae6-96d6-ec66015a65a6", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "714da3f7-2df4-46a9-869d-4a29a10fb8fb", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "18542344-87b8-4621-8160-7ce12fee4de6", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}, {"id": "6f73c866-7725-45f7-92d2-87b24589af2e", "nom": "ECS", "kind": "section"}, {"id": "2306b7c7-7c99-4a6f-9c6e-ce637c308529", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "17cc6696-edee-4319-aed1-380edd7a9f2b", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde retour", "kind": "point"}, {"id": "aaede262-cd21-4d70-812b-de145cda962c", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Pompe primaire ECS", "kind": "point"}, {"id": "5ce2afcb-7d93-4bfd-9598-254876edf052", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut ECS", "kind": "point"}, {"id": "5c5b0ffb-77f3-4a8a-ab0e-110d0bbafc8a", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 1", "kind": "point"}, {"id": "f1c66919-65b2-4c9e-9f8d-5115db9ebdab", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 2", "kind": "point"}, {"id": "f04a45d1-279b-4924-a03c-0eae668c01d8", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe primaire ECS", "kind": "point"}, {"id": "bec354bb-67ef-44f8-b90b-141e3b57130b", "nom": "CTA", "kind": "section"}, {"id": "3d7f1013-3546-4105-8016-ea23358f93eb", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Moteur Air Soufflé", "kind": "point"}, {"id": "1c7a9f0f-b22a-408e-8d72-5be09cd953eb", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Moteur Air Soufflé", "kind": "point"}, {"id": "6125e0dc-3686-4bfa-a65a-94e4ad1fb034", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Débit Air Soufflé", "kind": "point"}, {"id": "315340b8-b42e-47d0-86d1-b0758a635202", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Soufflé", "kind": "point"}, {"id": "10493097-8762-4071-ac99-2f5962064f8c", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Moteur Air Repris", "kind": "point"}, {"id": "c1e7fdae-db48-430d-b8ff-dfe7b39c3201", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Moteur Air Repris", "kind": "point"}, {"id": "2f161c01-8112-4d51-8661-815d054c78d0", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Débit Air Repris", "kind": "point"}, {"id": "473ee247-100d-4a01-b698-217ba9382421", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Repris", "kind": "point"}, {"id": "43ae84b8-e53c-4f39-858f-1f0225ae6f9d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Après Echangeur", "kind": "point"}, {"id": "8ca2d078-7984-4c30-b5e0-a1cf4e48052d", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne Chaud", "kind": "point"}, {"id": "89d44729-8689-47a2-93fa-d4620a6ff790", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne Froid", "kind": "point"}, {"id": "38daff08-0ab3-44d6-89b1-5144de785017", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Pressostat Filtre d'Air Neuf", "kind": "point"}, {"id": "29153dfd-67b5-4318-99dd-ec1d4217aa7c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Pressostat Filtre d'Air Repris", "kind": "point"}, {"id": "0f7b59b9-f1ef-4b0d-b134-12ef01618798", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Neuf", "kind": "point"}, {"id": "283cdf86-8922-453c-bb64-5e2fab114d4f", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Neuf", "kind": "point"}, {"id": "d285d053-304e-4a44-889b-6a999d0e00be", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Soufflé", "kind": "point"}, {"id": "28f9efad-6fe5-4524-abf1-2f6740704182", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Regeté", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.923	2026-07-06 18:40:30.423	cmr98uwge000w821xu2hfplt6	\N
cmr9k01f90006h31xocagbm8y	[DEMO] Rénovation chaufferie — Hirson	SISTEM	Rénovation chaufferie — Hirson	2026-04-24 18:28:42.931	[{"id": "1f6b33a1-51de-4954-9bdc-cb05f76092bd", "nom": "ECS", "kind": "section"}, {"id": "2d1c6a5e-8f27-40c6-8ce5-daf9e9aa486d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "090a0708-535b-49c2-9f9d-bb7f66da5c5d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde retour", "kind": "point"}, {"id": "07fee29a-5213-443c-ae3e-4eab4513f026", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Pompe primaire ECS", "kind": "point"}, {"id": "6afb076b-7d05-4b7f-9278-aafdf0f37115", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut ECS", "kind": "point"}, {"id": "ea6d862d-adf2-422f-adb3-3dce41d34735", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 1", "kind": "point"}, {"id": "d2953ea6-9ddb-4d8a-a507-de91e38c9939", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 2", "kind": "point"}, {"id": "d6a535a9-11fd-491e-a5b4-fb21a4fa8934", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe primaire ECS", "kind": "point"}, {"id": "b6ec9ab6-7d03-48fc-994f-84da03072feb", "nom": "Généralité", "kind": "section"}, {"id": "582e64a0-9bb5-43cb-b857-9377c138308f", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "9879004a-c644-4196-9340-d5c19fac6659", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "02fb3c13-43c6-427f-af2e-5e0995df0a7b", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "835130f5-a0f1-4d64-ba09-d4efd520a335", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "fcf7fdc1-4682-45aa-97fb-9ad301ea93ae", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "d9bad2bf-1940-4726-b2d9-b4872a0cc005", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "20e7bb7a-89de-4751-9138-9809f2f4694f", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "7763cff7-eabf-4e6a-8930-9bf472b45102", "nom": "CTA", "kind": "section"}, {"id": "fc0c9b8f-97db-44aa-9e31-3782352f1d62", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Moteur Air Soufflé", "kind": "point"}, {"id": "912b977a-55c1-4ae3-b389-879bc598ba00", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Moteur Air Soufflé", "kind": "point"}, {"id": "32a06b48-9623-4125-8a51-f4b83acdd428", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Débit Air Soufflé", "kind": "point"}, {"id": "2e0f19e3-9090-44d5-b187-44854006f993", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Soufflé", "kind": "point"}, {"id": "021764d7-d0e6-4dd6-9476-aee5cafbfd92", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Moteur Air Repris", "kind": "point"}, {"id": "3edb7d23-c25f-40be-9654-32660d24a848", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Moteur Air Repris", "kind": "point"}, {"id": "966f92a1-cabe-488f-ac47-35d3cee6af81", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Débit Air Repris", "kind": "point"}, {"id": "5e76e311-c436-498d-a3d0-a8a47af969a5", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Repris", "kind": "point"}, {"id": "7c036c14-4043-4ead-83b7-1b50ff7bf400", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Après Echangeur", "kind": "point"}, {"id": "a41106e2-e75e-4ff1-992f-ac7dae6aa25d", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne Chaud", "kind": "point"}, {"id": "19fcc6a8-f32e-4a56-910e-b6a7397cf42b", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne Froid", "kind": "point"}, {"id": "70e4c9ec-728a-40d7-906f-525450dc2eaf", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Pressostat Filtre d'Air Neuf", "kind": "point"}, {"id": "90e20dee-8a49-4e1b-8a08-efff8beb18cd", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Pressostat Filtre d'Air Repris", "kind": "point"}, {"id": "e99aff60-9d3d-44ce-a891-d3e70d42194b", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Neuf", "kind": "point"}, {"id": "d3417eb7-a6a8-4f7e-a0c3-fc96d8a05ec0", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Neuf", "kind": "point"}, {"id": "7ba2e907-2542-421a-ae70-451bf5171317", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Soufflé", "kind": "point"}, {"id": "b1a62e72-855c-436e-893e-fc13ff2bfba4", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Regeté", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.933	2026-07-06 18:40:30.436	cmr98uwgi004r821xqfpp2sad	\N
cmr9k01fe0007h31xj1ay37aq	[DEMO] Bureaux — Château-Thierry	DUPONT CHAUFFAGE SERVICES	Bureaux — Château-Thierry	2026-02-10 19:28:42.937	[{"id": "57f4a71d-6d80-4105-bb4b-77d287ebf3c6", "nom": "Chaudiere", "kind": "section"}, {"id": "24735df9-de85-43c8-bec0-3bde47542b4b", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 1", "kind": "point"}, {"id": "f9b1c285-dddb-4db5-950f-608ef4ef34e7", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 2", "kind": "point"}, {"id": "7991970b-4e28-4f54-bfd1-39cdb32b0159", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 1", "kind": "point"}, {"id": "f0cf674d-295d-41fb-8172-42d1d3da1ea0", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 2", "kind": "point"}, {"id": "bd983a1b-1199-4d22-87c9-e1860cd7fd98", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 1", "kind": "point"}, {"id": "4c5c16b3-683a-4611-8a6c-b5ec770913ae", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 2", "kind": "point"}, {"id": "5be60ce1-da05-43d8-9878-b8474c47fc0c", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "f7316b91-1923-463a-9ce5-fb5755210e24", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "11c0a066-3d11-4252-9eb2-1158e75a4ddb", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Capteur pression", "kind": "point"}, {"id": "c849f7e1-cede-4f33-8c21-8b3a6a393722", "nom": "Généralité", "kind": "section"}, {"id": "b6fa387d-4806-4dda-9642-bf416cb4ecdf", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "c2f22396-0b8f-4940-97a2-c6fedde006a9", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "8ef98fd7-40a7-4dfd-a838-bf9002a48a23", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "15c4c4ba-1342-405f-8e65-c17539939546", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "ef1093e4-0ee4-41c6-a870-4a7a2a011906", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "c6169e6e-3f76-473e-bf49-85acb1d6f2d9", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "16b8daef-ff4a-4f42-99c8-08a3a85d262f", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "a84236f2-3e9c-4cd2-a391-0256677aa4b3", "nom": "Circuit Régulé", "kind": "section"}, {"id": "b387897c-29d9-465a-b7e9-ebcf459e3d03", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "b7618324-649f-4405-985f-519396e446c6", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "b38c1e8e-7802-4ee5-aa9e-6eb8d622517a", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "b8ff9455-d4e0-4847-96d3-874e8ce11170", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "1c532bb8-1bf8-40a7-b763-f16640c3d9c9", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "ab41ed73-3513-4310-b1a4-6aeb9af5de3e", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "aa3c60e6-3d00-4c15-a6f7-d495c90a0e6d", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "ee4689bd-f599-4ca9-b478-30873e24d90e", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "c0bab4d2-d699-4e89-8b9a-61fb70ffcbae", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "21964a23-0244-489b-b995-ed4cb7747dea", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.938	2026-07-06 18:40:30.444	cmr98uwgf001t821x5y0hb07t	\N
cmr9k01fr0009h31xeoe3jetv	[DEMO] Centre technique — Compiègne	CC du PAYS NOYONNAIS	Centre technique — Compiègne	2025-07-27 18:28:42.949	[{"id": "76f49aed-917c-4dd5-bddc-563e34faba17", "nom": "Généralité", "kind": "section"}, {"id": "45b9f1ba-f55f-49b9-ad37-bf3f420ada9d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "34a96acf-b0a6-4d35-aca4-1f93b441664f", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "7a8935be-3b22-4e3c-ad61-7ec14ebd9503", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "da74bdb7-a878-40b7-9691-34a79eff8d93", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "3260a135-62fa-4d28-b9ae-453eaff869fa", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "8cfbed8d-644b-40a6-8145-4a78eae0c31c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "fe14bea3-298f-4c6c-8842-6e0aa64088a5", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "b83045c0-e61f-47d8-b2a2-436933bd0678", "nom": "Circuit Régulé", "kind": "section"}, {"id": "a4510af4-2c5d-4ea7-a22e-597125ee2dbc", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "41a01bbf-bf68-4a25-be1d-416723139619", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "9c3397da-9de3-4a2d-bc66-64748371150f", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "3d1a9269-ae93-49fd-972d-57929d021d64", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "ce82de17-fefd-4f41-a32d-6792fcee1f8e", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "789bd3f8-dd37-45d6-a9c4-769b092680cd", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "6b48512c-d241-47d7-8285-fc04e4ad6adb", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "67a27e1e-6c42-45a8-90fa-e70d6217f1a8", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "2474cf06-c434-4e2d-8782-33fd3ef5156d", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "d96e811f-5719-4170-b2fb-2406a4fe0392", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}, {"id": "9e04bea9-bd4b-4078-b46c-b6e4ddfbb51b", "nom": "ECS", "kind": "section"}, {"id": "297ffa27-aa58-4647-bacf-59ab9ce21f1d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "b11a94e5-20a8-41bb-9dd7-9f88b14f5c98", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde retour", "kind": "point"}, {"id": "dac0253d-6400-4bd1-b4ca-b2f1824f448a", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Pompe primaire ECS", "kind": "point"}, {"id": "99712077-8de3-40a5-b318-cbae7d410c49", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut ECS", "kind": "point"}, {"id": "67683ecc-d022-4df8-9609-424a440d84fe", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 1", "kind": "point"}, {"id": "003898eb-0d1e-49c3-869a-160a9bb0f25a", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe bouclage 2", "kind": "point"}, {"id": "fd49e9b4-2962-44ce-846b-b850c3ddc7cf", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Pompe primaire ECS", "kind": "point"}, {"id": "7ac7ff64-10a3-4864-b427-bf550cf6d38e", "nom": "Chaudiere", "kind": "section"}, {"id": "6b73608f-ca49-488f-8868-d30c2c7c271f", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 1", "kind": "point"}, {"id": "10aac602-10c9-47f1-b381-8445486ba63c", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 2", "kind": "point"}, {"id": "04a4afad-66cb-44c7-b3be-3d57e62ceb7d", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 1", "kind": "point"}, {"id": "48aecf62-2dff-4dc1-830d-7c336890e160", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 2", "kind": "point"}, {"id": "75b94ec7-422c-4c32-9ec3-9bfed37b2bd7", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 1", "kind": "point"}, {"id": "02fc0073-fb29-4204-a9ec-45c377630409", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 2", "kind": "point"}, {"id": "78a99e91-6249-4832-8489-f4cd82853524", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "dcd55c25-7fa1-4a36-b8bf-c5e8938c8e47", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "53af75f1-9f42-496a-b564-cef1f105942b", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Capteur pression", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.951	2026-07-06 18:40:30.459	cmr98uwgd000m821xnmxcsua2	\N
cmr9k01fl0008h31xwjwdp40z	\N	CENTRE HOSPITALIER DE LAON	Extension CTA — Chauny	2025-07-26 00:00:00	[{"id": "3ed7fc0b-5b58-4a1f-b7a5-9021c9b4f4c1", "nom": "Généralité", "kind": "section"}, {"id": "336bcff1-60c9-4606-9a76-fd978aeba987", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "b9d33616-e0a2-4621-83dd-b695d0bfb84d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "3e086a8c-09ac-4cdd-afde-6ec820ffd4b1", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "4537e996-ace9-4591-839f-dbf056afa1c5", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "55d77012-8072-4836-8514-26cfdcde119f", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "f4cc6c91-ea5b-4221-911c-05db5a4f258b", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "58aa9a92-232d-44d9-9c77-e2497087bd45", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "4595e971-556d-4c95-a6b7-9e6f71f5d099", "nom": "CTA", "kind": "section"}, {"id": "302f0ca4-101d-483e-b697-bee53b7154f5", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Moteur Air Soufflé", "kind": "point"}, {"id": "88516c2c-d8d3-41da-9e5b-50f2bf90d1d7", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Moteur Air Soufflé", "kind": "point"}, {"id": "07d55083-9208-46e0-8a32-ce59bf77f70d", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Débit Air Soufflé", "kind": "point"}, {"id": "aa21f0ce-f773-4f62-bce8-ef38c1124cb9", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Soufflé", "kind": "point"}, {"id": "db597650-058c-441e-927f-5df54516b12d", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Moteur Air Repris", "kind": "point"}, {"id": "1e46c737-2abd-4667-bd68-79be6dcbb229", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Moteur Air Repris", "kind": "point"}, {"id": "553c6d2d-cc2a-4cc9-9093-a518a957cc67", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Défaut Débit Air Repris", "kind": "point"}, {"id": "8b24cd6f-61ae-4b24-872a-1a264009587c", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Repris", "kind": "point"}, {"id": "66c7f213-f421-47a6-90a8-9ec02108980e", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Après Echangeur", "kind": "point"}, {"id": "2545ef73-5706-4359-8940-6d3d0abf2f2e", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne Chaud", "kind": "point"}, {"id": "64b837ee-d4f3-4751-8335-0492ae7ff857", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne Froid", "kind": "point"}, {"id": "12f353c7-8bde-40a9-ba6f-93a67ecada8d", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Pressostat Filtre d'Air Neuf", "kind": "point"}, {"id": "a7908099-8761-4c15-8584-d28ec14669d0", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Pressostat Filtre d'Air Repris", "kind": "point"}, {"id": "640b15fd-7d91-433b-b91b-7610c47416ac", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Air Neuf", "kind": "point"}, {"id": "c3ebcbd3-9f10-496e-9685-d9c3c413cdc9", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Neuf", "kind": "point"}, {"id": "ec7cabb0-4db4-4b7c-b14a-cf5612c4cc4e", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Soufflé", "kind": "point"}, {"id": "5a5929bb-ab11-48a2-8318-8e6b6a1c6be7", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande registre Air Regeté", "kind": "point"}, {"id": "f27c2476-243e-439d-9a1b-6fe49d6b721a", "nom": "Chaudiere", "kind": "section"}, {"id": "4a0d8c46-a8a6-43a4-ba02-2ccfd081f541", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 1", "kind": "point"}, {"id": "61250b8e-1220-4771-8d97-f572e39fa8ff", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ chaudiere 2", "kind": "point"}, {"id": "0ac1914e-9a5b-48f3-a718-ffd80e8f0dc1", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 1", "kind": "point"}, {"id": "8a4c743a-4256-44b0-90d8-0d6403b1dd56", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande chaudiére 2", "kind": "point"}, {"id": "155cebc4-889c-463b-b3c0-4d323dc140fb", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 1", "kind": "point"}, {"id": "386bcb99-b5c4-4ced-a1fc-e39720395675", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut chaudière 2", "kind": "point"}, {"id": "eb1e6e8e-4d16-4935-a55e-435f79d760f7", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "bcfb7dcc-7309-497e-a36b-766a908ad8ed", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande Vanne 2 voies", "kind": "point"}, {"id": "acb70b33-6a83-47d3-99b2-a9dd6a553822", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Capteur pression", "kind": "point"}, {"id": "84c8e736-0b96-4e6b-9b1a-f5d591a27b0b", "nom": "Circuit Régulé", "kind": "section"}, {"id": "d00c3c8e-efc8-432c-9b0c-7a3802bfdc43", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "266ddc71-82c1-49ac-aade-80455df983d2", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "473c02fb-888d-424c-80dd-5b7b1ae785c9", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "c644bf05-eaf5-4e7b-99f0-f5001c689ac0", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "bbe5bf9f-e41f-44e4-8357-b6adcdeb6f0d", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "4b604330-a82f-4f2f-9916-59145a1af62d", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "896d664a-231b-4a5a-bd84-8a3031b567c0", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "21c786f1-1d3e-48d3-a357-33bdb388bd86", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "96d795c6-0711-469b-8e44-dc4ede12759c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "0de5519f-2757-4414-874c-d6886e08d42a", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.945	2026-07-07 06:39:49.26	cmr98uwgd000r821xplptvmjf	\N
cmr9nxm2w0000n71x36hmxigq	\N	A M Chauffage	Testbis	2026-07-06 00:00:00	[{"id": "5ae6d02c-a712-4221-8f92-da677231025a", "nom": "", "kind": "section"}, {"id": "c65f1cc9-fc43-465d-8c35-5be8ad791951", "nom": "Circuit Régulé", "kind": "section"}, {"id": "eb0d1d19-e3d8-4780-8058-842a847c606d", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point", "note": ""}, {"id": "a487eed9-fffd-4910-855a-57774575ef37", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point", "note": ""}, {"id": "ed458e71-50ed-43e7-9795-cc7d420b5a29", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point", "note": ""}, {"id": "5b214842-634b-41f9-8157-6635153acf6e", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point", "note": ""}, {"id": "5b6ebdba-87d8-45d5-b639-4da475e838f7", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point", "note": ""}, {"id": "7571bd2b-8ce3-4d5a-ae95-f3896c1532ea", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point", "note": ""}, {"id": "7b01c30b-a594-4379-9ea1-ec6caa4b023a", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point", "note": ""}, {"id": "694741b5-1190-4864-8cb4-254892ac10aa", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point", "note": ""}, {"id": "cf99693a-053a-4890-8d3d-90d813a7e085", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point", "note": ""}, {"id": "7d372a6e-c163-45bb-8f18-3d508d4864f7", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point", "note": ""}]	cmr97nnti0000151x5566cx94	2026-07-06 20:18:48.2	2026-07-06 20:19:06.439	cmr98uwgc0001821xxwwf89um	\N
cmrawwspu0000r31xop5m82ph	\N			2026-07-07 00:00:00	[{"id": "a19ded89-bd13-458a-bd28-eea8c168f578", "nom": "Généralité", "kind": "section"}]	cmr97nnti0000151x5566cx94	2026-07-07 17:17:52.866	2026-07-07 17:17:53.939	\N	\N
cmr9k01f30005h31xah7dn2u1	\N	COPRECS	Piscine — Château-Thierry	2026-02-16 00:00:00	[{"id": "748b93ab-0a25-41d2-bc04-a09288333ec6", "nom": "Généralité", "kind": "section"}, {"id": "13104d1f-8ea1-4b43-8abd-230cab5004dd", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde extérieur", "kind": "point"}, {"id": "b0b64182-49d5-4c76-aac2-7fb5d24b0065", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ primaire", "kind": "point"}, {"id": "fe37e35e-516f-4dc7-84e6-c78441b6222a", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "d1ae6e07-70da-4bbc-bfbd-98d3b2d2450c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Eau", "kind": "point"}, {"id": "570a7846-dffa-4e7d-8d4e-65072379bf99", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Gaz", "kind": "point"}, {"id": "ff3c0bc0-d565-4d28-9780-d5421f326886", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut Manque Tension", "kind": "point"}, {"id": "5c9cb214-73e1-41ed-99d4-e1b3816381b3", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe de relevage", "kind": "point"}, {"id": "65fbe2c1-b847-4e29-830e-70bc5096686f", "nom": "Circuit Régulé", "kind": "section"}, {"id": "f0797e0b-2df9-4cbc-8e6b-85bc9ed8f38a", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde départ", "kind": "point"}, {"id": "e70763ff-9151-47af-ba56-f998db3b28c6", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde Retour", "kind": "point"}, {"id": "f158e4b6-59c5-4d4f-a613-30cc2493b393", "io": {"AI": 1, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "Sonde ambiance", "kind": "point"}, {"id": "48a6b4b8-90b7-443a-92cd-8ea124befa04", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Sonde ambiance Ss Fil", "kind": "point"}, {"id": "ae5e19c2-c0b2-4da6-9605-c518698fb7c9", "io": {"AI": 0, "AO": 1, "DI": 0, "DO": 0, "COM": 0}, "nom": "Commande Vanne 3 voies", "kind": "point"}, {"id": "daddd65c-9524-4e88-9abd-50b84bca1e64", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 1", "kind": "point"}, {"id": "923d7c78-aa98-45b1-beec-c476e06a4ad9", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 1, "COM": 0}, "nom": "Commande pompe 2", "kind": "point"}, {"id": "c5fd4338-cb59-4600-8750-48282946ca7c", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 1", "kind": "point"}, {"id": "af61379a-2c3e-4c97-adea-c34ffc34c5dd", "io": {"AI": 0, "AO": 0, "DI": 1, "DO": 0, "COM": 0}, "nom": "Defaut pompe 2", "kind": "point"}, {"id": "cb442a77-94f4-4644-b638-c62b55b04af8", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 1}, "nom": "Compteur Mbus", "kind": "point"}, {"id": "faaa2739-d684-44eb-b1a4-4db0390b8d6a", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "test", "kind": "point", "note": ""}, {"id": "40b586c6-ebf1-4f5b-920c-2bc9835afa51", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "", "kind": "point", "note": ""}, {"id": "9c492fdb-b635-419a-846c-a77294efae6a", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "", "kind": "point", "note": ""}, {"id": "71bf9c2c-3bab-49c3-ae6f-cf35b46b41a6", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "", "kind": "point", "note": ""}, {"id": "e874edb3-af1f-4ab1-9ce2-31a26bd0aac9", "io": {"AI": 0, "AO": 0, "DI": 0, "DO": 0, "COM": 0}, "nom": "", "kind": "point", "note": ""}]	cmr97nnti0000151x5566cx94	2026-07-06 18:28:42.927	2026-07-07 17:39:50.304	cmr98uwge0016821xipr1x4he	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public."User" (id, email, nom, "passwordHash", role, actif, "createdAt", "updatedAt") FROM stdin;
cmradfrl50000fq1x5gzxk8m4	romuald.wacomber@fareneit.fr	Romuald Wacomber	$2b$10$BqD7v60CaNCE2TjKbXCgxOHDqBZU1ikuPNkM4f68.wd9zCsnYauvK	ADMIN	t	2026-07-07 08:12:45.545	2026-07-07 08:13:08.721
cmradfrmd0001fq1xjpl1r013	tibo.roger@fareneit.fr	Tibo Roger	$2b$10$BqD7v60CaNCE2TjKbXCgxOHDqBZU1ikuPNkM4f68.wd9zCsnYauvK	ADMIN	t	2026-07-07 08:12:45.589	2026-07-07 08:13:08.773
cmradrt6l0000o51xdqcuyt0h	matthieu.grandsir@fareneit.fr	Matthieu Grandsir	$2b$10$iAH47vojz7np8DU9qK5wdOMaF6vKjcBQXOJztVeHc6Xt2Rxrrxqq.	ADMIN	t	2026-07-07 08:22:07.485	2026-07-07 08:22:07.485
cmr97nnti0000151x5566cx94	admin@dumortier02.fr	Administrateur	$2b$10$obja6gODqKzH2z4mAWhdtu6luVHmpsvRutzwVte4LS6CpCUlZs1mW	ADMIN	t	2026-07-06 12:43:10.038	2026-07-07 17:33:00.07
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: dumtools
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
7489713f-fc50-422b-b1e9-eaf978da829a	bacd0b21ef66b9c478d51b541a36cbe785a772aa87a5f2e04454b50af0d19c75	2026-07-06 12:40:55.84587+00	20260706124055_init	\N	\N	2026-07-06 12:40:55.802077+00	1
f7a20bc5-39f5-46a8-b979-20f59dc4d6d7	3a1c0516302dafb1d998d46c7992164f9a53c054e901fc76e221e10a85fe35a5	2026-07-06 13:16:46.316521+00	20260706131646_liste_points	\N	\N	2026-07-06 13:16:46.259533+00	1
c7da4867-1244-4c60-9ba0-4d01c1a89051	01f87a6a7fb1fb1cfe51205a629286cd3e90a649c1c1165120612783f811bbc1	2026-07-06 14:01:17.515623+00	20260706140117_affectation_es	\N	\N	2026-07-06 14:01:17.491968+00	1
c49fd961-1b22-4db0-ad96-faae8b57ba03	76e58a83ebf194247ffde081681f24109e3566d952868513274c86bcc50471ae	2026-07-06 18:34:26.17244+00	20260706183426_client_links_numero_why	\N	\N	2026-07-06 18:34:26.128819+00	1
cff3f250-7ec7-4fb2-9816-57efb3a39133	5a2485563ea85e49c774db58b01e7964f8a200a2b8f92da963ea2e021ad79e27	2026-07-07 07:12:54.206892+00	20260707071254_base_materiel	\N	\N	2026-07-07 07:12:54.177306+00	1
8bf7de96-2d30-4bdf-bb2c-ae559505b50b	e1ed04f70928f5e7d4aecedb3a16a9e2da28738f4a1901baf1f7e349c72c1264	2026-07-07 17:32:14.014888+00	20260707173213_modeles_points	\N	\N	2026-07-07 17:32:13.983761+00	1
\.


--
-- Name: AffectationProjet AffectationProjet_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."AffectationProjet"
    ADD CONSTRAINT "AffectationProjet_pkey" PRIMARY KEY (id);


--
-- Name: AutomateModele AutomateModele_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."AutomateModele"
    ADD CONSTRAINT "AutomateModele_pkey" PRIMARY KEY (id);


--
-- Name: Chantier Chantier_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."Chantier"
    ADD CONSTRAINT "Chantier_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: Modele Modele_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."Modele"
    ADD CONSTRAINT "Modele_pkey" PRIMARY KEY (id);


--
-- Name: ModuleModele ModuleModele_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."ModuleModele"
    ADD CONSTRAINT "ModuleModele_pkey" PRIMARY KEY (id);


--
-- Name: PointCatalog PointCatalog_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."PointCatalog"
    ADD CONSTRAINT "PointCatalog_pkey" PRIMARY KEY (id);


--
-- Name: PointsList PointsList_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."PointsList"
    ADD CONSTRAINT "PointsList_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AffectationProjet_clientId_idx; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE INDEX "AffectationProjet_clientId_idx" ON public."AffectationProjet" USING btree ("clientId");


--
-- Name: AffectationProjet_createdById_idx; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE INDEX "AffectationProjet_createdById_idx" ON public."AffectationProjet" USING btree ("createdById");


--
-- Name: AutomateModele_reference_key; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE UNIQUE INDEX "AutomateModele_reference_key" ON public."AutomateModele" USING btree (reference);


--
-- Name: Chantier_clientId_idx; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE INDEX "Chantier_clientId_idx" ON public."Chantier" USING btree ("clientId");


--
-- Name: Client_nom_key; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE UNIQUE INDEX "Client_nom_key" ON public."Client" USING btree (nom);


--
-- Name: Modele_nom_key; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE UNIQUE INDEX "Modele_nom_key" ON public."Modele" USING btree (nom);


--
-- Name: ModuleModele_type_key; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE UNIQUE INDEX "ModuleModele_type_key" ON public."ModuleModele" USING btree (type);


--
-- Name: PointCatalog_nom_key; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE UNIQUE INDEX "PointCatalog_nom_key" ON public."PointCatalog" USING btree (nom);


--
-- Name: PointsList_clientId_idx; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE INDEX "PointsList_clientId_idx" ON public."PointsList" USING btree ("clientId");


--
-- Name: PointsList_createdById_idx; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE INDEX "PointsList_createdById_idx" ON public."PointsList" USING btree ("createdById");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: dumtools
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: AffectationProjet AffectationProjet_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."AffectationProjet"
    ADD CONSTRAINT "AffectationProjet_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AffectationProjet AffectationProjet_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."AffectationProjet"
    ADD CONSTRAINT "AffectationProjet_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Chantier Chantier_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."Chantier"
    ADD CONSTRAINT "Chantier_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PointsList PointsList_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."PointsList"
    ADD CONSTRAINT "PointsList_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PointsList PointsList_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dumtools
--

ALTER TABLE ONLY public."PointsList"
    ADD CONSTRAINT "PointsList_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict DVk09rTV82noT4HSIgxYbvLdegKEDfdNza1DhbfhAM2sILYJkRvxK5loPkBmxcZ

